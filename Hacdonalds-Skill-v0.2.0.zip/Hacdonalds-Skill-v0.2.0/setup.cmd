@echo off
chcp 65001 >nul
setlocal
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
where python >nul 2>nul
if errorlevel 1 (
  where py >nul 2>nul
  if errorlevel 1 (
    echo 请先在 D 盘安装 Python 3.11 或更高版本。
    exit /b 2
  )
  py -3 "%~dp0scripts\bootstrap.py" %*
) else (
  python "%~dp0scripts\bootstrap.py" %*
)
exit /b %errorlevel%
