@echo off
chcp 65001 >nul
setlocal
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
if not defined HACDONALDS_HOME set "HACDONALDS_HOME=D:\AI-Tools\Hacdonalds"
set "HACDONALDS_HOME=%HACDONALDS_HOME:/=\%"
if /i not "%HACDONALDS_HOME:~0,3%"=="D:\" (
  echo HACDONALDS_HOME 必须位于 D 盘。
  exit /b 2
)
set "HACDONALDS_PYTHON=%HACDONALDS_HOME%\env\Scripts\python.exe"
if not exist "%HACDONALDS_PYTHON%" (
  echo 尚未初始化环境，请先运行 setup.cmd。
  exit /b 2
)
if "%~1"=="" (
  "%HACDONALDS_PYTHON%" "%~dp0scripts\run.py" doctor --format text
) else (
  "%HACDONALDS_PYTHON%" "%~dp0scripts\run.py" %*
)
exit /b %errorlevel%
