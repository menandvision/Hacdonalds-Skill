"""Local setup/health checks with fake transports and isolated Unicode paths."""

from contextlib import asynccontextmanager, redirect_stdout, redirect_stderr
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from hacdonalds.cli import main, read_arguments
from hacdonalds.config import Settings
from test_integration_layer import FakeTransport

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("bootstrap", ROOT / "scripts/bootstrap.py")
bootstrap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bootstrap)


class OnboardingTests(unittest.TestCase):
    def setUp(self):
        # The installation policy intentionally rejects C:. Valid installer
        # fixtures must use D: even when the user's system TEMP is on C:.
        base = bootstrap.DEFAULT_HOME / "tmp" if os.name == "nt" else Path(tempfile.gettempdir())
        base.mkdir(parents=True, exist_ok=True)
        self.fixture_directory = tempfile.TemporaryDirectory(dir=base)
        self.addCleanup(self.fixture_directory.cleanup)
        self.fixture_root = Path(self.fixture_directory.name)

    def test_check_discovers_required_tools_without_business_calls(self):
        names = ["query-nearby-stores", "query-meals", "query-meal-detail", "calculate-price"]
        transport = FakeTransport(pages=[{"tools": [{"name": name, "input_schema": {}} for name in names], "next_cursor": None}])
        @asynccontextmanager
        async def fake_connect(settings):
            yield transport
        output = io.StringIO()
        with patch("hacdonalds.cli.load_settings", return_value=Settings("test-health-token")), patch("hacdonalds.cli.connect", fake_connect), redirect_stdout(output):
            self.assertEqual(main(["check"]), 0)
        result = json.loads(output.getvalue())
        self.assertTrue(result["network_checked"] and result["ready"])
        self.assertEqual(result["tool_count"], 4)
        self.assertEqual(transport.calls, [])

    def test_check_missing_required_tool_is_not_ready(self):
        transport = FakeTransport(pages=[{"tools": [], "next_cursor": None}])
        @asynccontextmanager
        async def fake_connect(settings):
            yield transport
        output = io.StringIO()
        with patch("hacdonalds.cli.load_settings", return_value=Settings("test-health-token")), patch("hacdonalds.cli.connect", fake_connect), redirect_stdout(output):
            self.assertEqual(main(["check"]), 2)
        result = json.loads(output.getvalue())
        self.assertTrue(result["connected"])
        self.assertFalse(result["ready"])

    def test_missing_token_never_connects_and_doctor_is_offline(self):
        with tempfile.TemporaryDirectory(dir=self.fixture_root) as directory, patch.dict(os.environ, {}, clear=True), patch("hacdonalds.cli.connect") as connect:
            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                self.assertEqual(main(["check"], root=Path(directory)), 2)
                self.assertEqual(main(["doctor", "--format", "text"], root=Path(directory)), 2)
            connect.assert_not_called()

    def test_windows_utf8_bom_request_is_supported(self):
        with tempfile.TemporaryDirectory(dir=self.fixture_root) as directory:
            file = Path(directory) / "成员 需求.json"
            file.write_text('{"姓名":"小王"}', encoding="utf-8-sig")
            self.assertEqual(read_arguments(file), {"姓名": "小王"})

    def test_bootstrap_check_only_does_not_install_or_make_directories(self):
        with tempfile.TemporaryDirectory(dir=self.fixture_root) as directory:
            home = Path(directory) / "尚未安装 环境"
            with patch.dict(os.environ, {"HACDONALDS_HOME": str(home)}), patch.object(bootstrap, "initialize") as install, redirect_stdout(io.StringIO()) as output:
                self.assertEqual(bootstrap.main(["--check-only"]), 0)
            self.assertFalse(home.exists())
            install.assert_not_called()
            self.assertFalse(json.loads(output.getvalue())["installed"])

    @unittest.skipUnless(os.name == "nt", "D盘安装策略是Windows专属")
    def test_bootstrap_refuses_c_drive(self):
        with self.assertRaises(ValueError):
            bootstrap.layout("C:/not-allowed")

    def test_bootstrap_install_commands_isolate_environment_and_caches(self):
        with tempfile.TemporaryDirectory(dir=self.fixture_root) as directory:
            paths = bootstrap.layout(Path(directory) / "环境")
            commands = []
            def fake_runner(command, **kwargs):
                commands.append((command, kwargs))
            with patch.object(bootstrap.shutil, "which", return_value=None), redirect_stdout(io.StringIO()):
                bootstrap.initialize(paths, runner=fake_runner)
            self.assertEqual(len(commands), 3)
            self.assertIn("venv", commands[0][0])
            self.assertIn("--locked", commands[-1][0])
            for _, kwargs in commands:
                self.assertEqual(kwargs["env"]["UV_PROJECT_ENVIRONMENT"], str(paths["env"]))
                self.assertTrue(kwargs["env"]["UV_CACHE_DIR"].startswith(str(paths["home"])))

    @unittest.skipUnless(os.name == "nt", "Windows启动脚本")
    def test_launchers_work_from_chinese_space_directory(self):
        with tempfile.TemporaryDirectory(prefix="接入 空格 ", dir=self.fixture_root) as directory:
            root = Path(directory)
            shutil.copytree(ROOT / "src", root / "src", ignore=shutil.ignore_patterns("__pycache__"))
            shutil.copytree(ROOT / "scripts", root / "scripts", ignore=shutil.ignore_patterns("__pycache__"))
            for file in ("start.cmd", "setup.cmd", "pyproject.toml"):
                shutil.copy2(ROOT / file, root / file)
            env = dict(os.environ, PYTHONUTF8="1", HACDONALDS_HOME="D:/AI-Tools/Hacdonalds")
            # cmd.exe accepts a quoted batch path via the extra outer quotes.
            for file, args in (("start.cmd", "--help"), ("setup.cmd", "--check-only")):
                command = f'cmd.exe /d /s /c ""{root / file}" {args}"'
                result = subprocess.run(command, env=env,
                                        capture_output=True, encoding="utf-8", timeout=20)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertIn("Hacdonald" if file == "start.cmd" else "python_supported", result.stdout)


if __name__ == "__main__":
    unittest.main()
