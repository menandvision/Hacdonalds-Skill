"""Cache/concurrency tests use synthetic menu data and never contact MCP."""

import asyncio
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest

from hacdonalds.catalogue_cache import CatalogueCache
from hacdonalds.errors import HacdonaldsError
from hacdonalds.meal_workflow import collect_catalogue, plan_meals
from hacdonalds.crew import apply_changes
from test_planning import FakeClient, request


class CacheTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.now = 1000
        self.cache = CatalogueCache(Path(self.tmp.name), clock=lambda: self.now)

    async def test_hit_avoids_collection_but_always_quotes_new_baskets(self):
        first = await plan_meals(FakeClient(), request(), limit=8, cache=self.cache)
        second_client = FakeClient(surcharge=123)
        second = await plan_meals(second_client, request(), limit=8, cache=self.cache)
        self.assertTrue(second["catalogue"]["cache_info"]["hit"])
        self.assertTrue(second_client.calls)
        self.assertTrue(all(n == "calculate-price" for n, _ in second_client.calls))
        self.assertEqual(second["plans"][0]["official_quote"]["amount_fen"], first["plans"][0]["official_quote"]["amount_fen"] + 123)
        for plan in second["plans"]:
            self.assertEqual(plan["official_quote"]["amount_fen"], plan["reference_total_fen"] + 123)

    async def test_expiry_refresh_and_limit_are_isolated(self):
        await plan_meals(FakeClient(), request(), limit=8, cache=self.cache)
        for change in ("expiry", "refresh", "limit"):
            client = FakeClient()
            if change == "expiry":
                self.now += 600
            result = await plan_meals(client, request(), limit=12 if change == "limit" else 8,
                                      cache=self.cache, refresh=change == "refresh")
            self.assertFalse(result["catalogue"]["cache_info"]["hit"])
            self.assertIn("query-meals", [name for name, _ in client.calls])
        self.assertIsNone(self.cache.load("9999999", 8))

    async def test_corrupt_context_future_and_version_are_not_used(self):
        await plan_meals(FakeClient(), request(), limit=8, cache=self.cache)
        path = self.cache.path("1234567", 8)
        original = path.read_text(encoding="utf-8")
        for mutation in ("broken", "context", "future", "version"):
            if mutation == "broken":
                path.write_text("{", encoding="utf-8")
            else:
                entry = json.loads(original)
                if mutation == "context":
                    entry["catalogue"]["context"]["orderType"] = 2
                elif mutation == "future":
                    entry["saved_at"] = self.now + 60
                else:
                    entry["version"] = -1
                path.write_text(json.dumps(entry), encoding="utf-8")
            self.assertIsNone(self.cache.load("1234567", 8), mutation)

    async def test_business_failure_invalidates_and_never_retries(self):
        await plan_meals(FakeClient(), request(), limit=8, cache=self.cache)
        client = FakeClient(failure=True)
        result = await plan_meals(client, request(), limit=8, cache=self.cache)
        self.assertEqual(result["status"], "no_verified_plan")
        self.assertTrue(result["catalogue_invalidated"])
        self.assertIsNone(self.cache.load("1234567", 8))
        baskets = [json.dumps(args["items"], sort_keys=True) for _, args in client.calls]
        self.assertEqual(len(baskets), len(set(baskets)))

    async def test_max_two_concurrent_tasks_and_stable_menu_order(self):
        class Slow(FakeClient):
            active = 0
            maximum = 0
            async def call(self, name, args):
                if name != "query-meals":
                    self.active += 1
                    self.maximum = max(self.maximum, self.active)
                    try:
                        await asyncio.sleep(0.001 if args.get("code") == "S" else 0.004)
                        return await super().call(name, args)
                    finally:
                        self.active -= 1
                return await super().call(name, args)
        client = Slow()
        progress = []
        catalogue = await collect_catalogue(client, "1234567", limit=8, progress=progress.append)
        self.assertEqual(client.maximum, 2)
        self.assertEqual([p["code"] for p in catalogue["products"]], catalogue["attempted_codes"])
        self.assertTrue(any("已完成 4/4" in p for p in progress))

    async def test_fatal_error_cancels_pending_work_and_is_not_cached(self):
        class AuthFailure(FakeClient):
            async def call(self, name, args):
                if name == "query-meal-detail":
                    raise HacdonaldsError("AUTH_FAILED", "认证失败")
                return await super().call(name, args)
        with self.assertRaises(HacdonaldsError) as caught:
            await plan_meals(AuthFailure(), request(), limit=8, cache=self.cache)
        self.assertEqual(caught.exception.code, "AUTH_FAILED")
        self.assertIsNone(self.cache.load("1234567", 8))

    async def test_explicit_refresh_can_requote_without_changing_requirements(self):
        data = request()
        self.assertEqual(apply_changes(data, {}, allow_no_change=True), data)
        with self.assertRaises(HacdonaldsError):
            apply_changes(data, {})


if __name__ == "__main__":
    unittest.main()
