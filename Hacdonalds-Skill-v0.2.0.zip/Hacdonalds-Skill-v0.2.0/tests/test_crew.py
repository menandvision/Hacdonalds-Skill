"""Offline session revisions use the real workflow with synthetic prices."""

import asyncio
from contextlib import redirect_stderr, redirect_stdout
from copy import deepcopy
from io import StringIO
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import AsyncMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hacdonalds.cli import main, parser
from hacdonalds.crew import apply_changes, revise_crew, show_crew, start_crew
from hacdonalds.errors import HacdonaldsError
from hacdonalds.meal_workflow import plan_meals
from hacdonalds.sessions import CrewSessionStore
from test_planning import FakeClient, request


class ChangeTests(unittest.TestCase):
    def test_id_updates_add_remove_and_budget_preserve_other_fields(self):
        before = request()
        original = deepcopy(before)
        after = apply_changes(before, {"budget_fen": 6000,
            "member_updates": [{"id": "one", "drink": "required"}],
            "remove_member_ids": ["two"], "add_members": [{"id": "three", "hunger": 2}]})
        self.assertEqual(before, original)
        self.assertEqual(after["store_code"], before["store_code"])
        self.assertEqual(after["budget_fen"], 6000)
        self.assertEqual([m["id"] for m in after["crew"]], ["one", "three"])
        self.assertEqual(after["crew"][0]["exclude_keywords"], ["牛肉"])
        self.assertEqual(after["crew"][0]["drink"], "required")
        self.assertEqual(after["crew"][1]["drink"], "optional")

    def test_conflicting_unknown_and_non_request_fields_are_rejected(self):
        bad = [{}, {"store_code": "7654321"}, {"members": {}},
               {"budget_fen": True}, {"member_updates": {}},
               {"member_updates": [{"id": "absent", "hunger": 2}]},
               {"member_updates": [{"id": "one"}]},
               {"member_updates": [{"id": "one", "quantity": 2}]},
               {"member_updates": [{"id": "one", "drink": "none"}, {"id": "one", "hunger": 5}]},
               {"member_updates": [{"id": "one", "hunger": 5}], "remove_member_ids": ["one"]},
               {"remove_member_ids": ["one", "one"]},
               {"remove_member_ids": ["absent"]},
               {"remove_member_ids": ["one", "two"]},
               {"add_members": [{"id": "one"}]},
               {"add_members": [{"id": "three", "token": "never-store"}]},
               {"add_members": [{"id": "three"}, {"id": "three"}]},
               {"budget_fen": 5000}]
        for changes in bad:
            with self.subTest(changes=changes), self.assertRaises(HacdonaldsError):
                apply_changes(request(), changes)


class CrewTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.store = CrewSessionStore(self.root)
        self.client = FakeClient()

    async def planner(self, data, *, limit):
        self.assertEqual(set(data), {"store_code", "budget_fen", "crew"})
        return await plan_meals(self.client, data, limit=limit)

    async def start(self):
        return await start_crew(self.store, request(), self.planner, limit=8)

    async def test_start_and_show_separate_current_request_and_verified_snapshot(self):
        result = await self.start()
        self.assertEqual(result["status"], "verified")
        self.assertEqual(result["revision"], 1)
        self.assertTrue(result["last_verified_is_current"])
        self.assertEqual(result["request"], result["last_verified"]["request"])
        self.assertEqual(show_crew(self.store, result["session_id"])["last_verified"]["revision"], 1)

    async def test_valid_revision_records_requirement_and_food_diffs(self):
        initial = await self.start()
        result = await revise_crew(self.store, initial["session_id"], 1,
            {"member_updates": [{"id": "one", "drink": "required"}]}, self.planner, limit=8)
        self.assertEqual(result["revision"], 2)
        self.assertEqual(result["status"], "verified")
        self.assertEqual(result["request_diff"]["member_updates"][0]["fields"]["drink"], {"before": "none", "after": "required"})
        diff = result["last_attempt"]["food_diff"]
        self.assertTrue(diff["available"])
        self.assertEqual(diff["baseline_revision"], 1)
        changes = [m for c in diff["comparisons"] for m in c.get("members", [])]
        self.assertTrue(any(m["member_id"] == "one" and any(p["code"] == "D" for p in m["added"]) for m in changes))
        self.assertEqual(result["history"][-1]["status"], "verified")

    async def test_invalid_and_stale_revision_make_zero_calls_and_do_not_write(self):
        initial = await self.start()
        path = self.store.path(initial["session_id"])
        before = path.read_bytes()
        self.client.calls.clear()
        for revision, changes in [(1, {"budget_fen": -1}), (0, {"budget_fen": 6000}),
                                  (2, {"budget_fen": 6000}), (1, {"member_updates": [{"id": "missing", "drink": "none"}]})]:
            with self.subTest(revision=revision, changes=changes), self.assertRaises(HacdonaldsError):
                await revise_crew(self.store, initial["session_id"], revision, changes, self.planner)
            self.assertEqual(self.client.calls, [])
            self.assertEqual(path.read_bytes(), before)

    async def test_dry_run_neither_calls_planner_nor_changes_state(self):
        planner = AsyncMock()
        fresh = await start_crew(self.store, request(), planner, dry_run=True)
        self.assertEqual(fresh["status"], "dry_run")
        self.assertFalse(self.store.directory.exists())
        initial = await self.start()
        path = self.store.path(initial["session_id"])
        before = {p.name: p.read_bytes() for p in path.parent.iterdir()}
        result = await revise_crew(self.store, initial["session_id"], 1, {"budget_fen": 6000}, planner, dry_run=True)
        self.assertEqual(result["proposed_revision"], 2)
        self.assertEqual(result["base_revision"], 1)
        self.assertEqual(before, {p.name: p.read_bytes() for p in path.parent.iterdir()})
        planner.assert_not_called()

    async def test_network_failure_saves_new_needs_and_retains_old_success(self):
        initial = await self.start()
        observed = []
        async def broken(data, *, limit):
            pending = self.store.load(initial["session_id"])
            observed.append((pending["revision"], pending["request"]["budget_fen"], pending["last_attempt"]["status"]))
            raise RuntimeError("secret-upstream-message")
        result = await revise_crew(self.store, initial["session_id"], 1, {"budget_fen": 6000}, broken)
        self.assertEqual(observed, [(2, 6000, "pending")])
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["request"]["budget_fen"], 6000)
        self.assertEqual(result["last_verified"], initial["last_verified"])
        self.assertFalse(result["last_verified_is_current"])
        self.assertIn("旧需求", result["notice"])
        self.assertNotIn("secret-upstream-message", json.dumps(result))
        self.assertEqual(self.store.load(initial["session_id"])["revision"], 2)

    async def test_no_feasible_plan_keeps_low_budget_and_previous_verified(self):
        initial = await self.start()
        result = await revise_crew(self.store, initial["session_id"], 1, {"budget_fen": 100}, self.planner, limit=8)
        self.assertEqual(result["status"], "no_verified_plan")
        self.assertEqual(result["request"]["budget_fen"], 100)
        self.assertEqual(result["last_verified"]["revision"], 1)
        self.assertFalse(result["last_attempt"]["food_diff"]["available"])

    async def test_avoid_keeps_dietary_block_without_business_calls(self):
        initial = await self.start()
        self.client.calls.clear()
        result = await revise_crew(self.store, initial["session_id"], 1,
            {"member_updates": [{"id": "one", "avoid": ["allergy"]}]}, self.planner)
        self.assertEqual(result["status"], "needs_dietary_verification")
        self.assertEqual(self.client.calls, [])
        self.assertFalse(result["last_verified_is_current"])

    async def test_concurrent_writer_is_rejected_before_planner(self):
        initial = await self.start()
        planner = AsyncMock()
        with self.store.lock(initial["session_id"]):
            with self.assertRaises(HacdonaldsError) as caught:
                await revise_crew(self.store, initial["session_id"], 1, {"budget_fen": 6000}, planner)
        self.assertEqual(caught.exception.code, "SESSION_BUSY")
        planner.assert_not_called()
        self.assertEqual(self.store.load(initial["session_id"])["revision"], 1)

    async def test_cancelled_revision_is_saved_and_lock_released(self):
        initial = await self.start()
        async def cancelled(data, *, limit):
            raise asyncio.CancelledError()
        with self.assertRaises(asyncio.CancelledError):
            await revise_crew(self.store, initial["session_id"], 1, {"budget_fen": 6000}, cancelled)
        self.assertEqual(show_crew(self.store, initial["session_id"])["status"], "cancelled")
        with self.store.lock(initial["session_id"]):
            self.assertEqual(self.store.load(initial["session_id"])["revision"], 2)

    async def test_token_is_redacted_in_saved_response_and_returned_state(self):
        secret = "TEST-ONLY-SECRET"
        self.store = CrewSessionStore(self.root, token=lambda: secret)
        async def no_plan(data, *, limit):
            return {"status": "no_verified_plan", "plans": [], "echo": secret, "Authorization": "Bearer another-secret"}
        result = await start_crew(self.store, request(), no_plan)
        persisted = self.store.path(result["session_id"]).read_text(encoding="utf-8")
        self.assertNotIn(secret, persisted)
        self.assertNotIn(secret, json.dumps(result))
        self.assertNotIn("another-secret", persisted)
        self.assertFalse(list(self.store.directory.glob("*.tmp")))

    async def test_session_id_cannot_escape_project(self):
        for identity in ("../credentials", "..\\credentials", "x" * 32):
            with self.subTest(identity=identity), self.assertRaises(HacdonaldsError):
                self.store.load(identity)


class CrewCLITests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.request_path = self.root / "request.json"
        self.request_path.write_text(json.dumps(request()), encoding="utf-8")

    def test_original_plan_and_interactive_session_still_parse(self):
        self.assertEqual(parser().parse_args(["session"]).command, "session")
        args = parser().parse_args(["plan", "--request", str(self.request_path)])
        self.assertEqual(args.limit, 24)

    def test_dry_run_is_offline_without_credentials_or_session_state(self):
        with patch("hacdonalds.cli.connect") as connect, patch("hacdonalds.cli.load_settings") as settings, redirect_stdout(StringIO()) as out:
            code = main(["crew", "start", "--request", str(self.request_path), "--dry-run"], root=self.root)
        self.assertEqual(code, 0)
        self.assertFalse(json.loads(out.getvalue())["network_called"])
        self.assertFalse((self.root / ".local").exists())
        connect.assert_not_called()
        settings.assert_not_called()

    def test_invalid_start_does_not_load_credentials_connect_or_save(self):
        self.request_path.write_text('{"store_code":"123","budget_fen":true,"crew":[]}', encoding="utf-8")
        with patch("hacdonalds.cli.connect") as connect, patch("hacdonalds.cli.load_settings") as settings, redirect_stderr(StringIO()) as err:
            code = main(["crew", "start", "--request", str(self.request_path)], root=self.root)
        self.assertEqual(code, 2)
        self.assertIn("INVALID_PLAN_REQUEST", err.getvalue())
        self.assertFalse((self.root / ".local").exists())
        connect.assert_not_called()
        settings.assert_not_called()

    def test_missing_credentials_save_pending_needs_as_failed_and_show_offline(self):
        with patch.dict(os.environ, {}, clear=True), patch("hacdonalds.cli.connect") as connect, redirect_stdout(StringIO()) as out:
            code = main(["crew", "start", "--request", str(self.request_path)], root=self.root)
        result = json.loads(out.getvalue())
        self.assertEqual(code, 2)
        self.assertEqual(result["last_attempt"]["error"]["code"], "TOKEN_MISSING")
        self.assertEqual(result["request"], request())
        connect.assert_not_called()
        with patch("hacdonalds.cli.load_settings") as settings, redirect_stdout(StringIO()) as shown:
            self.assertEqual(main(["crew", "show", "--session", result["session_id"]], root=self.root), 0)
        self.assertEqual(json.loads(shown.getvalue())["revision"], 1)
        settings.assert_not_called()


if __name__ == "__main__":
    unittest.main()
