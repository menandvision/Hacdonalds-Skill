"""Dietary coverage and manual recovery tests never contact a business API."""

import asyncio
from contextlib import redirect_stderr, redirect_stdout
from copy import deepcopy
from io import StringIO
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import AsyncMock, patch

from hacdonalds.catalogue_cache import CatalogueCache
from hacdonalds.cli import main, parser, run_live
from hacdonalds.config import Settings
from hacdonalds.crew import food_diff, revise_crew, start_crew
from hacdonalds.errors import HacdonaldsError
from hacdonalds.explain import render_text, summarize
from hacdonalds.meal_workflow import plan_meals
from hacdonalds.partial import plan_with_reservations, prepare_request
from hacdonalds.recovery import recovery_options, with_recovery
from hacdonalds.sessions import CrewSessionStore
from test_planning import FakeClient, request


def dietary_request(budget=5000):
    data = request(budget)
    data["crew"][0]["avoid"] = ["allergy"]
    return data


class PartialRecoveryTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.store = CrewSessionStore(self.root)
        self.client = FakeClient()

    async def planner(self, data, *, limit):
        return await plan_meals(self.client, data, limit=limit)

    async def test_partial_keeps_original_dietary_needs_and_uses_only_unreserved_budget(self):
        data = dietary_request()
        before = deepcopy(data)
        result = await plan_with_reservations(data, self.planner, reservations_fen={"one": 1000}, limit=8)
        self.assertEqual(data, before)
        self.assertEqual(result["status"], "partial_verified")
        self.assertEqual(result["request"], before)
        self.assertEqual(result["effective_request"]["budget_fen"], 4000)
        self.assertEqual([m["id"] for m in result["effective_request"]["crew"]], ["two"])
        self.assertEqual(result["coverage"]["covered_member_ids"], ["two"])
        self.assertEqual(result["coverage"]["pending_member_ids"], ["one"])
        self.assertFalse(result["coverage"]["complete"])
        self.assertFalse(result["coverage"]["reservations_are_spending"])
        for plan in result["plans"]:
            subtotal = plan["official_quote"]["amount_fen"]
            self.assertLessEqual(subtotal, 4000)
            self.assertEqual(plan["remaining_budget_fen"], 4000 - subtotal)
        summary = summarize(result)
        self.assertIsNone(summary["recommendation"])
        self.assertEqual(summary["plans"][0]["remaining_budget_fen"], 4000 - result["plans"][0]["official_quote"]["amount_fen"])
        text = render_text(summary)
        for expected in ("团队需求尚未完成", "已覆盖 two", "待覆盖 one", "不是实际消费", "官方小计", "其余成员可用预算 40.00 元"):
            self.assertIn(expected, text)

    async def test_missing_reservations_all_dietary_and_exhausted_budget_do_not_call_planner(self):
        all_dietary = dietary_request()
        all_dietary["crew"][1]["avoid"] = ["other"]
        cases = [(dietary_request(), None, "needs_dietary_verification"),
                 (dietary_request(), {}, "needs_dietary_verification"),
                 (all_dietary, {"one": 1000, "two": 1000}, "needs_dietary_verification"),
                 (dietary_request(), {"one": 5000}, "insufficient_unreserved_budget"),
                 (dietary_request(), {"one": 5001}, "insufficient_unreserved_budget")]
        for data, reservations, status in cases:
            planner = AsyncMock()
            with self.subTest(reservations=reservations, status=status):
                result = await plan_with_reservations(data, planner, reservations_fen=reservations)
                self.assertEqual(result["status"], status)
                self.assertFalse(result["plans"])
                self.assertTrue(result["recovery_options"])
                planner.assert_not_called()
                self.assertEqual(with_recovery(result)["recovery_options"], result["recovery_options"])

    async def test_invalid_reservation_mappings_fail_before_any_planning_or_save(self):
        for reservations in ({"missing": 100}, {"two": 100}, {"one": True}, {"one": 0},
                             {"one": -1}, {"one": 1.5}, {"one": "100"}, []):
            planner = AsyncMock()
            with self.subTest(reservations=reservations), self.assertRaises(HacdonaldsError) as caught:
                await start_crew(self.store, dietary_request(), planner, reservations_fen=reservations)
            self.assertEqual(caught.exception.code, "INVALID_RESERVATIONS")
            planner.assert_not_called()
            self.assertFalse((self.root / ".local").exists())

    async def test_reservation_only_revision_inherits_replaces_clears_and_drops_resolved_ids(self):
        initial = await start_crew(self.store, dietary_request(), self.planner)
        identity = initial["session_id"]
        self.assertEqual(initial["status"], "needs_dietary_verification")
        partial = await revise_crew(self.store, identity, 1, {}, self.planner,
                                    reservations_fen={"one": 1000}, limit=8)
        self.assertEqual(partial["revision"], 2)
        self.assertEqual(partial["last_verified"]["result"]["status"], "partial_verified")
        self.assertTrue(partial["last_verified_is_current"])
        inherited = await revise_crew(self.store, identity, 2, {"budget_fen": 6000}, self.planner, limit=8)
        self.assertEqual(inherited["reservations_fen"], {"one": 1000})
        self.client.calls.clear()
        cleared = await revise_crew(self.store, identity, 3, {}, self.planner, reservations_fen={})
        self.assertEqual(cleared["status"], "needs_dietary_verification")
        self.assertEqual(cleared["reservations_fen"], {})
        self.assertEqual(self.client.calls, [])
        self.assertEqual(cleared["last_verified"]["revision"], 3)
        self.assertFalse(cleared["last_verified_is_current"])
        restored = await revise_crew(self.store, identity, 4, {}, self.planner, reservations_fen={"one": 1200}, limit=8)
        full = await revise_crew(self.store, identity, 5, {"member_updates": [{"id": "one", "avoid": []}]}, self.planner, limit=8)
        self.assertEqual(restored["reservations_fen"], {"one": 1200})
        self.assertEqual(full["reservations_fen"], {})
        self.assertEqual(full["status"], "verified")

    async def test_changed_coverage_disables_historical_price_comparison(self):
        full = await start_crew(self.store, request(), self.planner, limit=8)
        partial = await revise_crew(self.store, full["session_id"], 1,
            {"member_updates": [{"id": "one", "avoid": ["allergy"]}]}, self.planner,
            reservations_fen={"one": 1000}, limit=8)
        self.assertEqual(partial["last_attempt"]["food_diff"]["reason"], "COVERAGE_CHANGED")
        self.assertNotIn("official_total_change_fen", json.dumps(partial["last_attempt"]["food_diff"]))
        same_scope = await revise_crew(self.store, full["session_id"], 2, {"budget_fen": 6000}, self.planner, limit=8)
        self.assertTrue(same_scope["last_attempt"]["food_diff"]["available"])
        self.assertIn("official_total_change_fen", json.dumps(same_scope["last_attempt"]["food_diff"]))

    async def test_reservation_only_diff_tracks_confirmation_amount_change_and_clear(self):
        initial = await start_crew(self.store, dietary_request(), self.planner)
        identity = initial["session_id"]
        previous_amount = None
        for revision, reservations, phrase in (
                (1, {"one": 1000}, "从 未确认 变为 10.00 元"),
                (2, {"one": 1200}, "从 10.00 元 变为 12.00 元"),
                (3, {}, "从 12.00 元 变为 未确认（已清除）")):
            expected = {"one": {"before": previous_amount, "after": reservations.get("one")}}
            preview = await revise_crew(self.store, identity, revision, {}, self.planner,
                                        reservations_fen=reservations, dry_run=True, limit=8)
            self.assertEqual(preview["reservation_diff"], expected)
            self.assertIn(phrase, render_text(summarize(preview, crew=True)))
            self.assertEqual(self.store.load(identity)["revision"], revision)
            result = await revise_crew(self.store, identity, revision, {}, self.planner,
                                       reservations_fen=reservations, limit=8)
            saved = self.store.load(identity)
            self.assertEqual(result["request"], initial["request"])
            self.assertEqual(result["reservation_diff"], expected)
            self.assertEqual(saved["reservation_diff"], expected)
            self.assertEqual(saved["history"][-1]["reservation_diff"], expected)
            text = render_text(summarize(result, crew=True))
            self.assertIn(phrase, text)
            self.assertNotIn("无需求变化记录", text)
            previous_amount = reservations.get("one")

    async def test_start_reservation_confirmation_is_recorded_in_preview_and_history(self):
        expected = {"one": {"before": None, "after": 1000}}
        preview = await start_crew(self.store, dietary_request(), self.planner,
                                   reservations_fen={"one": 1000}, dry_run=True)
        self.assertEqual(preview["reservation_diff"], expected)
        self.assertFalse(self.store.directory.exists())
        result = await start_crew(self.store, dietary_request(), self.planner,
                                  reservations_fen={"one": 1000}, limit=8)
        self.assertEqual(result["reservation_diff"], expected)
        self.assertEqual(result["history"][0]["reservation_diff"], expected)
        self.assertIn("预留额：从 未确认 变为 10.00 元", render_text(summarize(result, crew=True)))

    async def test_partial_invalid_amount_empty_success_and_duplicate_coverage_are_rejected(self):
        valid = await plan_with_reservations(dietary_request(), self.planner, reservations_fen={"one": 1000}, limit=8)
        for mutation in ("over_budget", "empty", "wrong_scope"):
            workflow = deepcopy(valid)
            workflow["status"] = "verified"
            if mutation == "over_budget":
                workflow["plans"][0]["official_quote"]["amount_fen"] = 4001
            elif mutation == "empty":
                workflow["plans"] = []
            else:
                workflow["plans"][0]["assignments"].append(deepcopy(workflow["plans"][0]["assignments"][0]))
            with self.subTest(mutation=mutation), self.assertRaises(HacdonaldsError):
                await plan_with_reservations(dietary_request(), AsyncMock(return_value=workflow), reservations_fen={"one": 1000})

    async def test_partial_cache_hit_still_requotes_and_refresh_collects_again(self):
        cache = CatalogueCache(self.root)
        current = FakeClient()
        refresh = False
        async def cached(data, *, limit):
            return await plan_meals(current, data, limit=limit, cache=cache, refresh=refresh)
        first = await plan_with_reservations(dietary_request(), cached, reservations_fen={"one": 1000}, limit=8)
        current = FakeClient(surcharge=100)
        second = await plan_with_reservations(dietary_request(), cached, reservations_fen={"one": 1000}, limit=8)
        self.assertTrue(second["catalogue"]["cache_info"]["hit"])
        self.assertTrue(current.calls)
        self.assertTrue(all(name == "calculate-price" for name, _ in current.calls))
        self.assertEqual(second["plans"][0]["official_quote"]["amount_fen"], first["plans"][0]["official_quote"]["amount_fen"] + 100)
        refresh = True
        current = FakeClient()
        await plan_with_reservations(dietary_request(), cached, reservations_fen={"one": 1000}, limit=8)
        self.assertIn("query-meals", [name for name, _ in current.calls])

    async def test_reference_shortfall_is_scoped_and_never_invents_official_minimum(self):
        result = await plan_with_reservations(dietary_request(1500), self.planner, reservations_fen={"one": 1000}, limit=8)
        option = next(o for o in result["recovery_options"] if o["code"] == "REVIEW_REFERENCE_BUDGET")
        self.assertEqual(option["available_budget_fen"], 500)
        self.assertEqual(option["minimum_reference_fen"], 1300)
        self.assertEqual(option["reference_shortfall_fen"], 800)
        self.assertFalse(option["automatic"])
        text = render_text(summarize(result))
        self.assertIn("不是官方最终最低价", text)
        self.assertIn("参考差额 8.00 元", text)
        missing = await plan_with_reservations(dietary_request(), AsyncMock(), reservations_fen={})
        self.assertTrue(missing["recovery_options"][0]["requires_confirmation"])

    async def test_errors_preserve_current_needs_and_partial_history_with_manual_recovery(self):
        initial = await start_crew(self.store, dietary_request(), self.planner, reservations_fen={"one": 1000}, limit=8)
        for code in ("AUTH_FAILED", "RATE_LIMITED", "TIMEOUT"):
            async def failed(data, *, limit):
                raise HacdonaldsError(code, "测试失败")
            expected = self.store.load(initial["session_id"])["revision"]
            failed_state = await revise_crew(self.store, initial["session_id"], expected, {"budget_fen": 5000 + expected}, failed)
            self.assertEqual(failed_state["status"], "failed")
            self.assertEqual(failed_state["last_verified"]["revision"], 1)
            self.assertEqual(failed_state["request"]["crew"][0]["avoid"], ["allergy"])
            options = failed_state["last_attempt"]["recovery_options"]
            self.assertTrue(options)
            self.assertTrue(all(not o["automatic"] for o in options))
            self.assertIn("下一步：", render_text(summarize(failed_state, crew=True)))
        missing = {"status": "no_verified_plan", "request": request(), "diagnostics": [
            {"member_id": "one", "reason": "NO_COMPATIBLE_MAIN_SIDE_OR_DRINK"}]}
        self.assertEqual(recovery_options(missing)[0]["member_id"], "one")


class PartialCLITests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.request_path = self.root / "request.json"
        self.request_path.write_text(json.dumps(dietary_request()), encoding="utf-8")
        self.reservations_path = self.root / "reservations.json"
        self.reservations_path.write_text('{"one":1000}', encoding="utf-8")

    def test_plan_blocked_or_invalid_reservations_never_open_connection(self):
        settings = Settings("TEST-ONLY-TOKEN")
        for reservations, status in ((None, "needs_dietary_verification"), ({"one": 5000}, "insufficient_unreserved_budget"), ({"two": 100}, "INVALID_RESERVATIONS")):
            argv = ["plan", "--request", str(self.request_path)]
            if reservations is not None:
                self.reservations_path.write_text(json.dumps(reservations), encoding="utf-8")
                argv += ["--reservations", str(self.reservations_path)]
            with patch("hacdonalds.cli.connect") as connect:
                if status == "INVALID_RESERVATIONS":
                    with self.assertRaises(HacdonaldsError) as caught:
                        asyncio.run(run_live(parser().parse_args(argv), settings, self.root))
                    self.assertEqual(caught.exception.code, status)
                else:
                    result = asyncio.run(run_live(parser().parse_args(argv), settings, self.root))
                    self.assertEqual(result["status"], status)
                connect.assert_not_called()

    def test_crew_reservations_only_dry_run_validates_revision_without_credentials(self):
        async def planner(data, *, limit):
            return await plan_meals(FakeClient(), data, limit=limit)
        initial = asyncio.run(start_crew(CrewSessionStore(self.root), dietary_request(), planner))
        with patch("hacdonalds.cli.connect") as connect, patch("hacdonalds.cli.load_settings") as settings, redirect_stdout(StringIO()) as out:
            code = main(["crew", "revise", "--session", initial["session_id"], "--expected-revision", "1",
                         "--reservations", str(self.reservations_path), "--dry-run"], root=self.root)
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(out.getvalue())["proposed_revision"], 2)
        self.assertEqual(CrewSessionStore(self.root).load(initial["session_id"])["revision"], 1)
        connect.assert_not_called()
        settings.assert_not_called()

    def test_cli_errors_offer_structured_and_text_next_steps(self):
        self.request_path.write_text(json.dumps(request()), encoding="utf-8")
        for output_format in ("json", "text"):
            with patch("hacdonalds.cli.load_settings", side_effect=HacdonaldsError("TIMEOUT", "本轮超时")), redirect_stderr(StringIO()) as err:
                code = main(["plan", "--request", str(self.request_path), "--format", output_format], root=self.root)
            self.assertEqual(code, 2)
            if output_format == "json":
                self.assertEqual(json.loads(err.getvalue())["recovery_options"][0]["code"], "CHECK_CONNECTION")
            else:
                self.assertIn("下一步：", err.getvalue())

    def test_plan_missing_reservations_without_token_returns_confirmation_prompt_offline(self):
        with patch.dict(os.environ, {}, clear=True), patch("hacdonalds.cli.load_settings") as settings, patch("hacdonalds.cli.connect") as connect, redirect_stdout(StringIO()) as out:
            code = main(["plan", "--request", str(self.request_path)], root=self.root)
        result = json.loads(out.getvalue())
        self.assertEqual(code, 2)
        self.assertEqual(result["status"], "needs_dietary_verification")
        self.assertEqual(result["recovery_options"][0]["code"], "CONFIRM_DIETARY_RESERVATIONS")
        self.assertEqual(result["recovery_options"][0]["member_ids"], ["one"])
        settings.assert_not_called()
        connect.assert_not_called()


if __name__ == "__main__":
    unittest.main()
