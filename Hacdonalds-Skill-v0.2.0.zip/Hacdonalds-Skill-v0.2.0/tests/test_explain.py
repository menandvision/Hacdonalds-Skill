"""Descriptions use synthetic official quotes, never real menu prices."""

from contextlib import redirect_stderr, redirect_stdout
from copy import deepcopy
from io import StringIO
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hacdonalds.cli import main
from hacdonalds.crew import food_diff, request_diff
from hacdonalds.errors import HacdonaldsError
from hacdonalds.explain import render_text, summarize


def result_fixture():
    request = {"store_code": "1234567", "budget_fen": 5000, "crew": [
        {"id": "one", "hunger": 3, "drink": "none", "prefer": ["鸡", "薯条", "COFFEE"], "exclude_keywords": [], "avoid": []},
        {"id": "two", "hunger": 3, "drink": "optional", "prefer": [], "exclude_keywords": [], "avoid": []}]}
    def product(code, name):
        return {"code": code, "name": name}
    a, b, s, f = product("A", "测试鸡肉堡"), product("B", "测试牛肉堡"), product("S", "测试薯条"), product("F", "测试鱼肉堡")
    plans = []
    for strategy, amount, foods in (("saver", 2200, [a]), ("balanced", 2501, [a, a, s]), ("full_power", 3000, [f, s])):
        plans.append({"strategy": strategy, "reference_total_fen": 4999,
                      "official_quote": {"amount_fen": amount, "retrieved_at": f"quote-time-{strategy}"},
                      "remaining_budget_fen": 1,
                      "assignments": [{"member_id": "one", "products": deepcopy(foods)}, {"member_id": "two", "products": [deepcopy(b)]}]})
    return {"status": "verified", "request": request, "plans": plans, "quoted_at": "workflow-completed-time"}


def crew_fixture(current, previous=None):
    request = current["request"]
    baseline = {"revision": 1, "request": deepcopy(previous["request"]), "result": deepcopy(previous)} if previous else None
    return {"status": current["status"], "session_id": "a" * 32, "revision": 2, "request": deepcopy(request),
            "request_diff": request_diff(previous["request"] if previous else None, request),
            "last_attempt": {"revision": 2, "status": current["status"], "result": deepcopy(current), "food_diff": food_diff(baseline, current)},
            "last_verified": baseline, "last_verified_is_current": False}


class ExplainTests(unittest.TestCase):
    def test_official_money_quantities_preferences_and_quote_time(self):
        result = result_fixture()
        original = deepcopy(result)
        summary = summarize(result)
        self.assertEqual(summary["recommendation"]["strategy"], "balanced")
        balanced = summary["plans"][1]
        self.assertEqual(balanced["official_total_fen"], 2501)
        self.assertEqual(balanced["remaining_budget_fen"], 2499)
        self.assertEqual(balanced["assignments"][0]["products"][0]["quantity"], 2)
        self.assertEqual(balanced["assignments"][0]["preferences"], {"matched": ["鸡", "薯条"], "unmatched": ["COFFEE"]})
        text = render_text(summary)
        for value in ("25.01 元", "24.99 元", "测试鸡肉堡 × 2", "门店编码：1234567", "quote-time-balanced", "未设置", "未满足 COFFEE", "丰盛搭配"):
            self.assertIn(value, text)
        self.assertNotIn("workflow-completed-time", text)
        self.assertEqual(result, original)

    def test_real_official_difference_supports_more_less_and_same_price(self):
        for amount, phrase in ((2501, "多花 3.01 元"), (2100, "少花 1.00 元"), (2200, "同价")):
            with self.subTest(amount=amount):
                result = result_fixture()
                result["plans"][1]["official_quote"]["amount_fen"] = amount
                summary = summarize(result)
                comparison = summary["plans"][1]["comparison_to_saver"]
                self.assertEqual(comparison["official_difference_fen"], amount - 2200)
                self.assertEqual(comparison["members"][0]["added"][0]["quantity"], 1)
                self.assertIn(phrase, render_text(summary))

    def test_recommendation_fallback_does_not_invent_missing_plans(self):
        for indexes, strategy in (([0, 2], "saver"), ([2], "full_power"), ([], None)):
            with self.subTest(indexes=indexes):
                result = result_fixture()
                result["plans"] = [result["plans"][i] for i in indexes]
                summary = summarize(result)
                self.assertEqual(len(summary["plans"]), len(indexes))
                self.assertEqual(summary["recommendation"]["strategy"] if summary["recommendation"] else None, strategy)

    def test_incomplete_unknown_and_over_budget_results_are_never_recommended(self):
        for status in ("failed", "pending", "partial_verified", "unexpected_status", "needs_dietary_verification"):
            with self.subTest(status=status):
                result = result_fixture()
                result["status"] = status
                self.assertIsNone(summarize(result)["recommendation"])
        result = result_fixture()
        result["request"]["budget_fen"] = 1
        self.assertIsNone(summarize(result)["recommendation"])
        result["plans"][0]["official_quote"]["amount_fen"] = True
        self.assertEqual(len(summarize(result)["plans"]), 2)

    def test_crew_requirement_food_differences_and_old_history_warning(self):
        previous = result_fixture()
        current = deepcopy(previous)
        current["request"]["budget_fen"] = 4500
        current["request"]["crew"][0]["drink"] = "required"
        current["plans"][1]["assignments"][0]["products"].append({"code": "D", "name": "测试可乐"})
        current["plans"][1]["official_quote"]["amount_fen"] += 300
        state = crew_fixture(current, previous)
        text = render_text(summarize(state, crew=True))
        for value in ("总预算：50.00 元 → 45.00 元", "不要饮料 → 需要饮料", "餐品差异", "增加 测试可乐 × 1", "历史金额不作为当前报价", "历史方案（revision 1，非当前）"):
            self.assertIn(value, text)
        self.assertEqual(summarize(state, crew=True)["recommendation"]["strategy"], "balanced")
        state["status"] = state["last_attempt"]["status"] = "failed"
        state["last_attempt"] = {"revision": 2, "status": "failed", "error": {"code": "TIMEOUT", "message": "本轮超时"}}
        summary = summarize(state, crew=True)
        text = render_text(summary)
        self.assertIsNone(summary["recommendation"])
        self.assertIn("不能作为当前报价", text)
        self.assertIn("[TIMEOUT]", text)
        self.assertNotIn("推荐：均衡搭配", text)

    def test_crew_mismatched_revision_or_request_is_never_recommended(self):
        for mismatch in ("revision", "request"):
            with self.subTest(mismatch=mismatch):
                state = crew_fixture(result_fixture())
                if mismatch == "revision":
                    state["last_attempt"]["revision"] = 1
                else:
                    state["last_attempt"]["result"]["request"]["budget_fen"] = 6000
                self.assertIsNone(summarize(state, crew=True)["recommendation"])


class ExplainCLITests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.request_path = self.root / "request.json"
        self.request_path.write_text(json.dumps(result_fixture()["request"]), encoding="utf-8")

    def test_plan_json_is_default_and_saved_json_contains_same_summary(self):
        destination = self.root / "plan.json"
        with patch("hacdonalds.cli.load_settings", return_value=SimpleNamespace(token="PRIVATE")), patch("hacdonalds.cli.run_live", new=AsyncMock(return_value=result_fixture())), redirect_stdout(StringIO()) as output:
            code = main(["plan", "--request", str(self.request_path), "--output", str(destination)], root=self.root)
        payload = json.loads(output.getvalue())
        self.assertEqual(code, 0)
        self.assertEqual(payload, json.loads(destination.read_text(encoding="utf-8")))
        self.assertEqual(payload["summary"]["recommendation"]["strategy"], "balanced")

    def test_plan_text_and_errors_are_readable_and_redacted(self):
        result = result_fixture()
        result["plans"][0]["assignments"][0]["products"][0]["name"] = "PRIVATE"
        with patch("hacdonalds.cli.load_settings", return_value=SimpleNamespace(token="PRIVATE")), patch("hacdonalds.cli.run_live", new=AsyncMock(return_value=result)), redirect_stdout(StringIO()) as output:
            code = main(["plan", "--request", str(self.request_path), "--format", "text"], root=self.root)
        self.assertEqual(code, 0)
        self.assertIn("推荐：均衡搭配", output.getvalue())
        self.assertNotIn("PRIVATE", output.getvalue())
        with patch("hacdonalds.cli.load_settings", side_effect=HacdonaldsError("TOKEN_MISSING", "尚未配置凭证")), redirect_stderr(StringIO()) as error:
            code = main(["plan", "--request", str(self.request_path), "--format", "text"], root=self.root)
        self.assertEqual(code, 2)
        self.assertIn("操作未完成：[TOKEN_MISSING] 尚未配置凭证", error.getvalue())
        self.assertFalse(error.getvalue().startswith("{"))

    def test_crew_show_text_identifies_offline_saved_quote(self):
        state = crew_fixture(result_fixture())
        with patch("hacdonalds.cli.run_crew", new=AsyncMock(return_value=state)), redirect_stdout(StringIO()) as output:
            code = main(["crew", "show", "--session", state["session_id"], "--format", "text"], root=self.root)
        self.assertEqual(code, 0)
        self.assertIn("已保存的核价记录，查看未重新核价", output.getvalue())
        self.assertIn("quote-time-balanced", output.getvalue())

    def test_crew_dry_run_text_is_offline_and_displays_additions(self):
        path = self.root / "request.json"
        path.write_text(json.dumps(result_fixture()["request"]), encoding="utf-8")
        with patch("hacdonalds.cli.load_settings") as settings, patch("hacdonalds.cli.connect") as connect, redirect_stdout(StringIO()) as output:
            code = main(["crew", "--format", "text", "start", "--request", str(path), "--dry-run"], root=self.root)
        self.assertEqual(code, 0)
        self.assertIn("未联网、未保存", output.getvalue())
        self.assertIn("新增成员 one", output.getvalue())
        self.assertFalse((self.root / ".local").exists())
        settings.assert_not_called()
        connect.assert_not_called()


if __name__ == "__main__":
    unittest.main()
