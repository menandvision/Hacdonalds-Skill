---
name: hacdonalds
description: 为团队规划麦当劳餐食或修改配餐需求时，加载项目维护的 Hacdonald's Skill 工作流。
---

# Hacdonald's 项目入口

先读取并遵循 [canonical Skill](../../../skills/hacdonalds/SKILL.md)。本文件只负责项目级发现，不复制业务流程或请求协议；后续引用均相对 canonical Skill 所在目录解析。使用项目现有 Python CLI，无需另配第二套麦当劳 MCP。
