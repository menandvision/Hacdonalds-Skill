"""Concrete manual next steps from observed errors, never automatic retries."""


def recovery_options(result=None, *, code=None):
    result = result or {}
    options = []
    seen = set()

    def add(kind, message, next_step, **details):
        key = (kind, details.get("member_id"))
        if key not in seen:
            seen.add(key)
            options.append({"code": kind, "message": message, "next_step": next_step,
                            "automatic": False, **details})

    if code in {"TOKEN_MISSING", "AUTH_FAILED", "INVALID_TOKEN", "INVALID_CONFIG", "UNSAFE_CONFIG"}:
        add("CONFIGURE_CREDENTIALS", "凭证尚未配置或未通过认证。", "在本机终端运行 setup 配置或更新 Token，再手动执行；不要把 Token 发到聊天中。")
    elif code == "RATE_LIMITED":
        add("WAIT_AND_RETRY_MANUALLY", "官方接口限流，本轮没有自动重试。", "稍后再手动执行；团队会话先 crew show 读取最新 revision，再提交修改或 --refresh。")
    elif code in {"TIMEOUT", "CONNECTION_FAILED", "CONNECTION_CLOSED", "PROXY_FAILED", "TLS_FAILED", "UPSTREAM_HTTP_ERROR", "MCP_FAILED", "MCP_RPC_ERROR"}:
        add("CHECK_CONNECTION", "本轮连接或响应未完成，不能当作已核价成功。", "检查网络、代理及官方服务后手动再执行；crew show 可查看已保存需求与历史方案。")
    elif code in {"REVISION_CONFLICT", "SESSION_BUSY"}:
        add("READ_CURRENT_REVISION", "团队状态已变化或仍在执行。", "等待当前操作结束，先 crew show，再使用最新 expected-revision 提交。")
    elif code == "INVALID_RESERVATIONS":
        add("FIX_RESERVATIONS", "预算预留文件未通过校验。", "文件应为禁忌成员 ID 到正整数分的映射；金额必须经用户明确确认。")
    elif code:
        add("REVIEW_INPUT_OR_SERVICE", "本轮操作未完成。", "按错误说明检查输入；保留原需求，确认后手动执行，不自动放宽要求。")

    budget = (result.get("effective_request") or result.get("request") or {}).get("budget_fen")
    for diagnostic in result.get("diagnostics", []):
        reason = diagnostic.get("reason")
        if reason == "REFERENCE_BUDGET_TOO_LOW":
            minimum = diagnostic.get("minimum_reference_fen")
            details = {"minimum_reference_fen": minimum, "available_budget_fen": budget}
            if type(minimum) is int and type(budget) is int:
                details["reference_shortfall_fen"] = max(0, minimum - budget)
            add("REVIEW_REFERENCE_BUDGET", "当前采集范围内，满足硬约束的参考最低金额超过可用预算；这不是官方最终最低价。",
                "请用户确认是否调整预算或成员要求，或换门店新建团队；不会自动删饮品、减食量或修改禁忌。", **details)
        elif reason == "NO_COMPATIBLE_MAIN_SIDE_OR_DRINK":
            add("REVIEW_MEMBER_REQUIREMENTS", "当前采集范围没有满足该成员主食、小食或饮品要求的组合。",
                "确认该成员的名称排除和饮品要求；可手动 --refresh，或换门店新建团队；保持现有硬约束直到用户确认修改。",
                member_id=diagnostic.get("member_id"))
    rejected = {item.get("reason") for item in result.get("rejected", [])}
    if "OFFICIAL_PRICE_OVER_BUDGET" in rejected:
        add("REVIEW_OFFICIAL_BUDGET", "参考搭配的整篮官方核价超过可用预算。", "请用户确认是否调整预算或需求；不会把超预算方案作为有效方案展示。")
    if result.get("catalogue_invalidated") or rejected - {"OFFICIAL_PRICE_OVER_BUDGET"}:
        add("REFRESH_CATALOGUE", "部分商品或整篮核价未通过验证。", "保留需求，使用 --refresh 手动重新采集并核价；本轮没有自动重试。")
    if not options and result.get("status") in {"no_verified_plan", "no_feasible_reference_plan"}:
        add("REVIEW_CANDIDATE_SCOPE", "当前采集范围尚无可展示的已核价方案。", "检查成员要求及预算；可手动 --refresh 或换门店新建团队，不承诺全菜单不存在方案。")
    return options


def with_recovery(result):
    return dict(result, recovery_options=result["recovery_options"] if "recovery_options" in result else recovery_options(result))
