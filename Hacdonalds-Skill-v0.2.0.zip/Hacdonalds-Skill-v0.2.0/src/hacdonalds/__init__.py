"""Hacdonald's MCP integration layer."""

__version__ = "0.2.0"
