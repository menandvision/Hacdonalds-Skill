"""Atomic project-local crew state with process-level, nonblocking locks."""

from contextlib import contextmanager
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import tempfile
from uuid import uuid4

from .errors import HacdonaldsError
from .privacy import redact


def timestamp():
    return datetime.now(timezone.utc).isoformat()


class CrewSessionStore:
    def __init__(self, root: Path, *, token=lambda: ""):
        self.root = Path(root).resolve()
        self.directory = self.root / ".local" / "crew"
        self.token = token

    @staticmethod
    def new_id():
        return uuid4().hex

    def path(self, session_id):
        if not isinstance(session_id, str) or re.fullmatch(r"[0-9a-f]{32}", session_id) is None:
            raise HacdonaldsError("INVALID_SESSION_ID", "会话 ID 必须来自 crew start 的输出。")
        if not self.directory.resolve().is_relative_to(self.root):
            raise HacdonaldsError("UNSAFE_SESSION_PATH", "会话目录必须位于项目 .local 内。")
        path = self.directory / f"{session_id}.json"
        if path.is_symlink():
            raise HacdonaldsError("UNSAFE_SESSION_PATH", "会话文件不能是符号链接。")
        return path

    def load(self, session_id):
        path = self.path(session_id)
        try:
            state = json.loads(path.read_text(encoding="utf-8"))
            if (not isinstance(state, dict) or state.get("schema_version") != 1
                    or state.get("session_id") != session_id
                    or type(state.get("revision")) is not int or state["revision"] < 1
                    or not isinstance(state.get("request"), dict)
                    or not isinstance(state.get("last_attempt"), dict)):
                raise ValueError("invalid state")
            return state
        except FileNotFoundError:
            raise HacdonaldsError("SESSION_NOT_FOUND", "没有找到该团队会话，请检查 ID 或运行 crew start。") from None
        except (OSError, ValueError):
            raise HacdonaldsError("INVALID_SESSION_STATE", "无法读取团队会话，请保留文件并检查本地状态。") from None

    def save(self, state):
        path = self.path(state["session_id"])
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd, filename = tempfile.mkstemp(prefix="crew-", suffix=".tmp", dir=self.directory)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(redact(state, self.token()), handle, ensure_ascii=False, indent=2, allow_nan=False)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(filename, path)
        finally:
            Path(filename).unlink(missing_ok=True)

    @contextmanager
    def lock(self, session_id):
        # OS locks release automatically after a crash; the lock file remains
        # so unlinking cannot allow two processes to lock different inodes.
        path = self.path(session_id).with_suffix(".lock")
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        if path.is_symlink():
            raise HacdonaldsError("UNSAFE_SESSION_PATH", "会话锁文件不能是符号链接。")
        fd = os.open(path, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
        with os.fdopen(fd, "r+b") as handle:
            # Inspect the size without reading a byte another Windows process
            # may already have locked.
            if os.fstat(handle.fileno()).st_size == 0:
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            try:
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError:
                raise HacdonaldsError("SESSION_BUSY", "该团队正在规划或修改，请完成后重新读取 revision 再提交。") from None
            try:
                yield
            finally:
                if os.name == "nt":
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
