"""Disposable, versioned search references. Never cache a final basket quote."""

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import tempfile
import time

VERSION = 1
TTL_SECONDS = 600


class CatalogueCache:
    def __init__(self, root, *, clock=time.time):
        self.root = Path(root).resolve()
        self.directory = self.root / ".local" / "catalogue-cache"
        self.clock = clock

    def path(self, store_code, limit):
        if not self.directory.resolve().is_relative_to(self.root):
            raise ValueError("cache directory outside project")
        identity = {"version": VERSION, "storeCode": store_code, "orderType": 1, "beType": 1, "limit": limit}
        name = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
        path = self.directory / (name + ".json")
        if path.is_symlink():
            raise ValueError("symlink cache")
        return path

    @staticmethod
    def valid(catalogue, store_code):
        context = {"storeCode": store_code, "orderType": 1, "beType": 1}
        if not isinstance(catalogue, dict) or catalogue.get("store_code") != store_code or catalogue.get("context") != context:
            return False
        products = catalogue.get("products")
        if not isinstance(products, list) or len(products) > 32:
            return False
        codes = set()
        for p in products:
            if (not isinstance(p, dict) or not isinstance(p.get("code"), str) or not p["code"]
                    or p["code"] in codes or not isinstance(p.get("name"), str)
                    or p.get("role") not in {"main", "side", "drink"}
                    or type(p.get("reference_price_fen")) is not int or p["reference_price_fen"] < 0
                    or type(p.get("support_modify")) is not bool):
                return False
            codes.add(p["code"])
        return True

    def load(self, store_code, limit):
        try:
            entry = json.loads(self.path(store_code, limit).read_text(encoding="utf-8"))
            age = self.clock() - entry["saved_at"]
            if (entry.get("version") != VERSION or entry.get("limit") != limit
                    or not 0 <= age < TTL_SECONDS or not self.valid(entry.get("catalogue"), store_code)):
                return None
            catalogue = deepcopy(entry["catalogue"])
            catalogue["source"] = "cache"
            catalogue["cache_info"] = {"hit": True, "age_seconds": round(age, 3), "ttl_seconds": TTL_SECONDS}
            return catalogue
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def save(self, store_code, limit, catalogue):
        if not self.valid(catalogue, store_code):
            return False
        # Only normalized reference fields are persisted, never raw responses.
        clean = {key: deepcopy(catalogue[key]) for key in (
            "source", "store_code", "context", "retrieved_at", "products", "skipped", "scope", "attempted_codes")}
        filename = None
        try:
            destination = self.path(store_code, limit)
            self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
            fd, filename = tempfile.mkstemp(prefix="catalogue-", dir=self.directory)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump({"version": VERSION, "limit": limit, "saved_at": self.clock(), "catalogue": clean},
                          handle, ensure_ascii=False, allow_nan=False)
            os.replace(filename, destination)
            return True
        except (OSError, ValueError):
            return False
        finally:
            if filename:
                Path(filename).unlink(missing_ok=True)

    def invalidate(self, store_code, limit):
        try:
            self.path(store_code, limit).unlink(missing_ok=True)
        except (OSError, ValueError):
            pass
