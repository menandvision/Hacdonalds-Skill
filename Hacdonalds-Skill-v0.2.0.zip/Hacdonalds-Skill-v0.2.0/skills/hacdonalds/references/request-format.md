# v0.2 请求与团队变更协议

这是 Hacdonald's 自有协议，不是官方 MCP 工具参数。文件使用 UTF-8；实际请求保存在项目 `.local/`，不提交凭证或完整业务响应。

## 初始请求

```json
{
  "store_code": "3230320",
  "budget_fen": 8000,
  "crew": [
    {"id": "成员1", "hunger": 3, "drink": "optional", "prefer": ["鸡"], "exclude_keywords": [], "avoid": []},
    {"id": "成员2", "hunger": 4, "drink": "none", "prefer": [], "exclude_keywords": [], "avoid": []}
  ]
}
```

`3230320` 是沈阳历史演示店，运行前换成查询并选定的实际门店编码。

| 字段 | 约束 |
|---|---|
| `store_code` | 官方门店查询返回的纯数字字符串；会话中不换店 |
| `budget_fen` | 1–100000 整数分；80 元写 8000，不传浮点或布尔值 |
| `crew` | 1–10 人，成员 `id` 唯一且稳定，不能按数组位置识别人 |
| `hunger` | 1–5，默认 3；1–3 至少一份主食，4–5 另需一份小食，仅为搭配规则 |
| `drink` | `optional`／`required`／`none`，默认 optional |
| `prefer` | 餐名关键词软偏好；不保证满足 |
| `exclude_keywords` | 明确要求按名称排除时使用；大小写不敏感，不验证配料 |
| `avoid` | 原样保留配料禁忌或过敏要求；当前无法判定安全可食用 |

三个关键词数组默认 `[]`。不得增加 Token、联系方式、支付信息或未知字段。

## 变更文件

用于 `crew revise --changes 文件.json`，不是完整初始请求：

```json
{
  "budget_fen": 7500,
  "member_updates": [{"id": "成员1", "drink": "none"}]
}
```

可用字段为 `budget_fen`、`member_updates`、`add_members`、`remove_member_ids`。成员更新只支持 `hunger`、`drink`、`prefer`、`exclude_keywords`、`avoid`；新增成员使用初始请求的成员结构。相同 ID 不能重复更新或同时删除、更新；修改不存在的 ID 会被拒绝。未提及条件全部保留。

`--session` 和 `--expected-revision` 必填。先 `crew show`，读取 revision，再 dry-run；dry-run 不联网、不保存、不增加 revision。正式提交先保存新版本需求；后续规划失败也不回滚需求，旧报价独立保留为历史。版本冲突时重新读取，不能沿用旧版本强写。

`--refresh` 允许无 changes 手动重查；仅更新预留额时也可省略 changes。除此之外，空变更会返回 `NO_CHANGES`。

## 已确认预留额

`--reservations 文件.json` 的内容是独立映射，不写入初始请求或 changes：

```json
{"成员2": 2500}
```

仅接受**当前有 avoid 的成员**及正整数分。提交前需明确得到用户确认。未知成员、非禁忌成员、0、负数、浮点、布尔值均无效。

- 显式映射完整替换旧映射，不按键合并。
- revise 省略 `--reservations`，继承仍有 avoid 的成员预留；已删成员或已无 avoid 的成员不再继承。
- 显式文件 `{}` 清除所有预留确认，恢复为待确认状态。
- 只有所有禁忌成员都已确认，且仍有其他成员及正数可用预算，才为其他成员调用核价。
- 初始 `plan`／`crew start` 无可继承映射；预留未齐、全员禁忌或预算不足时不联网配餐。

## 返回状态

| 状态或字段 | 解释 |
|---|---|
| `verified` | 当前请求取得整篮核价方案；可按均衡、价格、丰盛的顺序推荐 |
| `partial_verified` | 仅 `coverage.covered_member_ids` 已核价；`pending_member_ids` 仍待处理，不表示全队完成 |
| `needs_dietary_verification` | 禁忌待核实或预留未齐；保留 avoid，不偷换名称过滤 |
| `insufficient_unreserved_budget` | 预留用尽预算，不能自动降低预留额 |
| `no_verified_plan` | 本次候选范围内未取得已核价方案，不代表全菜单无解 |
| `recovery_options` | 确定性的人工恢复建议，无自动重试 |

`plans[].assignments[].products` 每条代表一份，`items` 是篮子汇总数量。最终金额取 `official_quote.amount_fen`，时间取 `official_quote.retrieved_at`；`reference_total_fen` 仅用于搜索。

部分规划以 `effective_request` 为本次覆盖范围，`coverage.available_budget_fen = team_budget_fen - reserved_budget_fen`；余额为可用预算减已覆盖成员官方小计。预留不是消费，未覆盖成员没有已验证餐品。

默认 JSON 附 `summary`；`--format text` 显示逐人餐品、差异、门店与时间。`crew show` 标记 `view_only=true`、`network_checked=false`，即使 revision 当前也没有重新核价。CLI 完整 verified／dry-run 返回 0；部分或未完成规划返回 2；show 读取成功返回 0，不能仅凭退出码认定全队已核价。
