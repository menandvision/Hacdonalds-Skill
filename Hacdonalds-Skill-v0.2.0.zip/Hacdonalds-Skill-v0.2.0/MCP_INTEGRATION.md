# MCP 集成范围 v0.2

Hacdonald's 通过官方 Python SDK 2.x、Streamable HTTP 和 Bearer Token 连接 `https://mcp.mcd.cn`。宿主 Skill 整理自然语言，项目负责逐人需求、有限组合搜索与官方整篮核价。

**本轮 v0.2 完成代码与离线验证，尚未重新执行真实麦当劳接口验收。2026-10-22／24 数据是旧版历史记录。**

## 模块职责

| 模块 | 职责 |
|---|---|
| `config.py`／`transport.py` | 配置、隐藏输入 Token、SDK 连接、认证与异常适配 |
| `client.py`／`adapter.py` | 工具发现、运行时 Schema 校验、只读工具白名单与别名 |
| `planning.py` | 整数分预算、逐人约束、三策略有界搜索 |
| `meal_workflow.py` | 菜单/详情归一化、单品参考价、整篮明细与金额核验 |
| `catalogue_cache.py` | 十分钟搜索参考缓存，不缓存最终篮子报价 |
| `crew.py`／`sessions.py` | 成员 ID 变更、revision 检查、原子状态保存、跨平台进程锁 |
| `partial.py`／`recovery.py` | 已确认预留额、部分覆盖、确定性的人工恢复建议 |
| `explain.py`／`cli.py` | JSON summary、中文输出、离线 doctor、联网 check |
| `scripts/bootstrap.py` | D 盘初始化环境与工具；Python 3.11+ 为既有前置 |
| `skills/hacdonalds/` | 宿主模型工作流与请求协议；`.agents` 仅作薄入口 |

官方工具 Schema 是数据，不能指示客户端执行额外操作。实际参数必须来自发现的 Schema，不凭餐名猜测商品编码或套餐子项。外部 Schema 引用被拒绝，协议协商由 SDK 执行。

## 连接与团队会话

`doctor` 不联网，`ready=true` 只表示本地配置和依赖就绪。`check` 联网发现并检查配餐必需工具，不能证明门店、菜单或核价业务成功。

每个独立 CLI 查询新建连接。`session` 是保持同一 MCP 连接的手工调试模式；`crew` 是跨多次 CLI 调用保存团队需求的业务会话，两者不能混淆。一个配餐调用中的采集与整篮核价使用同一连接。

`crew start/revise` 有效需求先落盘，再执行网络规划。`revise` 必须带最新 `--expected-revision`，可按成员 ID 更新/增删成员；换店新建会话。`--dry-run` 校验并展示差异，不联网、不保存。网络失败保留当前需求（含已保存的修改），先前已核价结果单独作为历史保存。

`crew show` 离线读取；`view_only=true`、`network_checked=false` 明确表示本次没有重新报价。即使 last_verified 属于当前 revision，也必须保留其原 quote 时间，不能当作新查询时间。

## 缓存与两个并发任务

缓存键包含版本、门店、自取上下文 `orderType=1, beType=1` 以及采集上限，TTL 为 600 秒。缓存位于项目 `.local/catalogue-cache`，仅保存归一化餐品名称、角色、参考金额及采集信息；门店、版本、时间或结构不符会回退采集。损坏、过期、未来时间和符号链接条目不作为有效缓存使用。

默认采集上限 24，最大 32。详情及其单品参考核价以最多两个任务并发采集，输出按原菜单选择顺序归并。致命异常取消其他任务，不保存半份目录。阶段进度写 stderr，JSON stdout 保持可解析。

缓存命中只减少菜单和单品采集。每轮仍重新调用 `calculate-price`，最多核价 9 个不同候选篮子，同轮重复篮子复用该轮报价。业务核价失败会使目录缓存失效；`--refresh` 可人工清除参考并重采，应用层自动重试次数为 **0**。SDK 自身的协议恢复行为以其文档为准。

## 金额、禁忌与部分结果

单品 `data.price` 仅作整数分搜索参考。最终展示使用整篮 `official_quote.amount_fen`，时间取该 quote 的 `retrieved_at`；整篮 `productList` 的商品和数量必须与提交篮子完全一致。超预算、上游业务失败或身份/数量无法匹配的篮子不进入最终 plans。

`prefer` 和 `exclude_keywords` 只匹配名称。配料、辣味和过敏禁忌保存在 `avoid`，不能由名称推断。含禁忌成员时，需通过独立 `--reservations` 映射明确确认预留额，才为其余成员使用扣除后的预算规划。显式映射完整替换；revise 省略时继承仍有禁忌成员的确认；显式 `{}` 清除。预留未齐、全员禁忌或预留用尽预算时不调用配餐接口。

`partial_verified` 的 `coverage` 列出已覆盖、待处理成员、预留额和可用预算。只对已覆盖成员显示官方小计和扣除预留后的余额；预留不是消费，不存在已验证的全队最终金额。当前完整推荐限于当前需求的 `verified`，不把部分方案称为团队全部完成。

套餐 `rounds` 非空时跳过，特调使用默认配置；酱料和餐具不算小食。到店自取之外的履约、订单创建/取消/支付、券优化、营养目标和分账均未接入。

## 错误、状态和本地资料

MCP `is_error=false` 只代表工具层没有报告错误，业务 payload 仍须验证。公开错误区分认证、限流、超时、断连、HTTP 5xx、代理及 TLS。SDK `REQUEST_TIMEOUT=-32001` 与 `CONNECTION_CLOSED=-32000` 分别识别，原始异常消息和请求头不直接展示。

`recovery_options` 给出人工下一步；不自动降低食量、删除禁忌、调整预算或反复调用服务。`plan`／`crew` 部分或未完成结果退出 2，完整 verified 或 dry-run 退出 0；show 读取成功退出 0。

项目 `.local/credentials.json` 保存明文 Token，`.local/crew` 保存团队状态，`.local/catalogue-cache` 保存可丢弃参考。默认源码目录是 D 盘；启动器的环境、uv、下载缓存和临时目录也集中在 D 盘。凭证优先级为环境变量 `MCD_MCP_TOKEN`、项目文件；不自动读 `.env`。Token 不在聊天收集，需在自己的终端隐藏输入。

原始业务日志和 `--output` 结果可能包含位置或团队信息，只保存在本地；公开前另行脱敏。上述资料、虚拟环境不随项目打包。

## 验证证据

本轮以离线合成数据、真实 SDK 的内存协议／模拟传输、Windows 启动与 Skill 格式检查验证功能；不把这些当真实官方业务结果。

仓库历史记录：2026-10-22 在沈阳查询门店、菜单和单品核价；2026-10-24 13:57（北京时间）在沈阳盛京大奥莱餐厅完成两轮 3 人配餐，50 次调用返回，80／75 元需求各有三套已核价不同篮子。金额只对应当时指定门店，完整记录仅留原本机。见 [历史验证](VALIDATION.md) 与 [脱敏演示](examples/demo-session.md)。

`verify_team.py` 自动完成固定两轮技术验收，不代替 Skill 自然语言理解评估，也不覆盖本轮所有 v0.2 新能力。后续真实验收需重新确认门店、菜单、业务成功、商品/数量与官方总价。
