#!/usr/bin/env python3
"""Initialize the source package without installing anything outside drive D."""

import argparse
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_HOME = Path("D:/AI-Tools/Hacdonalds")


def layout(home=None):
    base = Path(home or os.environ.get("HACDONALDS_HOME", DEFAULT_HOME)).resolve()
    if os.name == "nt" and base.drive.upper() != "D:":
        raise ValueError("HACDONALDS_HOME 必须位于 D 盘，运行环境不会安装到 C 盘。")
    return {"home": base, "env": base / "env", "tools": base / "tools" / "uv",
            "cache": base / "cache", "tmp": base / "tmp", "runtimes": base / "runtimes" / "python"}


def environment(paths):
    env = os.environ.copy()
    env.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8", UV_PROJECT_ENVIRONMENT=str(paths["env"]),
               UV_CACHE_DIR=str(paths["cache"] / "uv"), PIP_CACHE_DIR=str(paths["cache"] / "pip"),
               UV_PYTHON_INSTALL_DIR=str(paths["runtimes"]), TMP=str(paths["tmp"]), TEMP=str(paths["tmp"]))
    return env


def python_in(directory):
    return directory / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def initialize(paths, runner=subprocess.run):
    env = environment(paths)
    for key in ("cache", "tmp", "runtimes"):
        paths[key].mkdir(parents=True, exist_ok=True)
    uv = shutil.which("uv")
    private_uv = paths["tools"] / ("Scripts/uv.exe" if os.name == "nt" else "bin/uv")
    if uv is None:
        if not private_uv.is_file():
            print("正在 D 盘准备 uv 工具，首次初始化需要网络。", flush=True)
            runner([sys.executable, "-m", "venv", str(paths["tools"])], env=env, check=True)
            runner([str(python_in(paths["tools"])), "-m", "pip", "install", "--index-url", "https://pypi.org/simple", "uv"],
                   env=env, check=True)
        uv = str(private_uv)
    print("正在按 uv.lock 同步项目依赖到 D 盘。", flush=True)
    runner([uv, "sync", "--locked", "--project", str(ROOT), "--python", sys.executable], env=env, check=True)
    print("初始化完成。请在自己的终端运行 start.cmd setup 隐藏输入 Token，然后运行 start.cmd check。")


def main(argv=None):
    parser = argparse.ArgumentParser(description="Hacdonald's 中文初始化，环境和缓存仅写入 D 盘")
    parser.add_argument("--check-only", action="store_true", help="仅报告路径和Python版本，不安装、不联网")
    args = parser.parse_args(argv)
    try:
        if sys.version_info < (3, 11):
            raise ValueError("需要 Python 3.11 或更高版本，请先安装到 D 盘。")
        paths = layout()
        if args.check_only:
            print(json.dumps({"python_supported": True, "project": str(ROOT),
                              "paths": {key: str(value) for key, value in paths.items()},
                              "environment_exists": python_in(paths["env"]).is_file(),
                              "network_checked": False, "installed": False}, ensure_ascii=False))
            return 0
        initialize(paths)
        return 0
    except (ValueError, OSError, subprocess.CalledProcessError):
        print("初始化未完成。请检查 Python 3.11+、D盘写入权限及网络；没有修改系统策略或全局客户端配置。", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
