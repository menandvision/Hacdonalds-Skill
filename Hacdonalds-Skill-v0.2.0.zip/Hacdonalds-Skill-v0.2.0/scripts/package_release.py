#!/usr/bin/env python3
"""Build a source ZIP with per-file integrity metadata and no local state."""

import argparse
import hashlib
import json
from pathlib import Path
import tomllib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {".git", ".local", ".venv", "venv", "env", "__pycache__", "node_modules",
            ".cache", ".uv-cache", "dist", "build", ".pytest_cache"}


def include_file(relative):
    if any(part.casefold() in EXCLUDED or part.endswith(".egg-info") for part in relative.parts):
        return False
    name = relative.name.casefold()
    if name.startswith(".env") and name != ".env.example":
        return False
    return name not in {"credentials.json", "file_sha256.json", ".ds_store"} and relative.suffix.casefold() not in {
        ".pyc", ".pyo", ".log", ".zip", ".sha256", ".pem", ".key", ".pfx"}


def package(root, output_directory):
    root, output_directory = Path(root).resolve(), Path(output_directory).resolve()
    version = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))["project"]["version"]
    folder = f"Hacdonalds-Skill-v{version}"
    files = sorted(path for path in root.rglob("*") if path.is_file() and not path.is_symlink()
                   and include_file(path.relative_to(root)))
    output_directory.mkdir(parents=True, exist_ok=True)
    destination = output_directory / f"{folder}.zip"
    manifest = {}
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            relative = path.relative_to(root).as_posix()
            data = path.read_bytes()
            manifest[relative] = hashlib.sha256(data).hexdigest()
            archive.writestr(f"{folder}/{relative}", data)
        archive.writestr(f"{folder}/FILE_SHA256.json", json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"))
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP integrity check failed")
    checksum = hashlib.sha256(destination.read_bytes()).hexdigest()
    destination.with_suffix(".zip.sha256").write_text(f"{checksum}  {destination.name}\n", encoding="ascii")
    return destination, checksum, len(files)


def main():
    parser = argparse.ArgumentParser(description="打包源码，排除凭证/缓存/环境，并生成 SHA-256")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    destination, checksum, count = package(ROOT, args.output)
    print(json.dumps({"zip": str(destination), "sha256": checksum, "source_files": count}, ensure_ascii=False))


if __name__ == "__main__":
    main()
