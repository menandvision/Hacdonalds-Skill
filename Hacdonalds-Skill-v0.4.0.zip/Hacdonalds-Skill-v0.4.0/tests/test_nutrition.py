"""Synthetic nutrition fixtures exercise arithmetic and matching, never live data."""

from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
import json

from hacdonalds.catalogue_cache import CatalogueCache
from hacdonalds.errors import HacdonaldsError
from hacdonalds.meal_workflow import plan_meals
from hacdonalds.nutrition import (collect_nutrition, match_nutrition, normalize_nutrition,
                                  product_kcal, summarize_nutrition)
from test_planning import FakeClient, PRODUCTS, request


def response(data):
    return {"data": data, "retrieved_at": "synthetic-nutrition-time"}


def matched(kcal):
    return {"status": "matched", "basis": "per_item", "kcal_per_item": kcal,
            "source": "list-nutrition-foods", "retrieved_at": "synthetic-nutrition-time"}


class NutritionTests(unittest.TestCase):
    def test_json_and_toon_are_equivalent_and_kj_has_an_explicit_unit(self):
        data = [{"productName": "测试鸡肉汉堡", "energyKcal": 450, "energyKj": 1883}]
        a = normalize_nutrition(response({"success": True, "data": {"foods": data}}))
        b = normalize_nutrition(response('[1]{productName,energyKcal,energyKj}:\n测试鸡肉汉堡,450,1883'))
        self.assertEqual(a["entries"], b["entries"])
        self.assertEqual(match_nutrition(PRODUCTS[0], a)["kcal_per_item"], 450)
        converted = normalize_nutrition(response([{"productName": "测试鸡肉汉堡", "energyKj": 418.4}]))
        self.assertEqual(match_nutrition(PRODUCTS[0], converted)["kcal_per_item"], 100)

    def test_prose_wrapped_json_toon_is_data_and_ambiguous_envelopes_are_rejected(self):
        envelope = json.dumps({"success": True, "data": '[1]{productName,energyKcal}:\n测试鸡肉汉堡,450'}, ensure_ascii=False)
        data = normalize_nutrition(response('服务器说明，仅供参考\n' + envelope))
        self.assertEqual(match_nutrition(PRODUCTS[0], data)["kcal_per_item"], 450)
        with self.assertRaises(ValueError):
            normalize_nutrition(response(envelope + '\n' + envelope + '\n说明'))

    def test_empty_kcal_uses_kj_but_explicit_per_100ml_is_not_a_portion(self):
        data = normalize_nutrition(response([{"productName": PRODUCTS[0]["name"], "energyKcal": " ", "energyKj": 418.4}]))
        self.assertEqual(match_nutrition(PRODUCTS[0], data)["kcal_per_item"], 100)
        for description in ('每100毫升', '每 100 ml', 'per 100ml', '/100ml'):
            data = normalize_nutrition(response([{"productName": PRODUCTS[-1]["name"], "energyKcal": 42,
                                                  "nutritionDescription": description}]))
            self.assertEqual(match_nutrition(PRODUCTS[-1], data)["reason"], 'PORTION_UNVERIFIED')

    def test_invalid_energy_never_becomes_zero(self):
        for value in (-1, True, float('nan'), float('inf'), 'invalid'):
            with self.subTest(value=value):
                data = normalize_nutrition(response([{"productName": PRODUCTS[0]["name"], "energyKcal": value}]))
                self.assertIsNone(product_kcal({"nutrition": match_nutrition(PRODUCTS[0], data)}))
        zero = normalize_nutrition(response([{"productName": PRODUCTS[0]["name"], "energyKcal": 0}]))
        self.assertEqual(match_nutrition(PRODUCTS[0], zero)["status"], 'matched')
        self.assertEqual(match_nutrition(PRODUCTS[0], zero)["kcal_per_item"], 0)

    def test_unknown_unit_basis_and_conflicting_energy_are_not_guessed(self):
        for fields in ({"energy": 100}, {"energy": 100, "unit": "cal", "basis": "per_item"},
                       {"energyKcal": 100, "basis": "per_100g"},
                       {"energyKcal": 100, "nutritionDescription": "每100g"},
                       {"energyKcal": 100, "energyKj": 2000}):
            with self.subTest(fields=fields):
                data = normalize_nutrition(response([dict(productName=PRODUCTS[0]["name"], **fields)]))
                self.assertEqual(match_nutrition(PRODUCTS[0], data)["status"], 'unknown')
        for energy in ({"value": 418.4, "unit": "kJ"}, '418.4 千焦'):
            data = normalize_nutrition(response([{"name": PRODUCTS[0]["name"], "energy": energy, "basis": "per_serving"}]))
            self.assertEqual(match_nutrition(PRODUCTS[0], data)["kcal_per_item"], 100)

    def test_size_and_identity_match_is_exact_and_ambiguous_rows_are_rejected(self):
        data = normalize_nutrition(response([{"productName": "测试可乐(中杯)", "energyKcal": 150},
                                             {"productName": "测试可乐(大杯)", "energyKcal": 200}]))
        self.assertEqual(match_nutrition({"code": "D", "name": "测试可乐(大杯)"}, data)["kcal_per_item"], 200)
        self.assertEqual(match_nutrition(PRODUCTS[-1], data)["status"], 'unknown')
        duplicate = normalize_nutrition(response([{"productName": PRODUCTS[0]["name"], "energyKcal": kcal} for kcal in (100, 200)]))
        self.assertEqual(match_nutrition(PRODUCTS[0], duplicate)["reason"], 'AMBIGUOUS_NUTRITION_MATCH')
        coded = normalize_nutrition(response([{"productName": '其他规格', 'productCode': PRODUCTS[0]['code'], "energyKcal": 100}]))
        self.assertEqual(match_nutrition(PRODUCTS[0], coded)["status"], 'unknown')
        ui = normalize_nutrition(response([{"productName": '测试 鸡肉汉堡', "energyKcal": 100}]))
        self.assertEqual(match_nutrition(dict(PRODUCTS[0], name='测试鸡肉汉堡【可特调】'), ui)["kcal_per_item"], 100)

    def test_portion_separator_is_normalized_without_merging_different_quantities(self):
        data = normalize_nutrition(response([{"productName": "测试麦辣鸡翅-2块", "energyKcal": 224},
                                             {"productName": "测试麦辣鸡翅-4块", "energyKcal": 448}]))
        for name in ('测试麦辣鸡翅2块', '测试麦辣鸡翅（2块）'):
            self.assertEqual(match_nutrition({"code": 'wing', "name": name}, data)["kcal_per_item"], 224)
        self.assertEqual(match_nutrition({"code": 'wing', "name": '测试麦辣鸡翅4块'}, data)["kcal_per_item"], 448)
        self.assertEqual(match_nutrition({"code": 'wing', "name": '测试麦辣鸡翅'}, data)["status"], 'unknown')

    def test_damaged_toon_rows_and_unsupported_text_fail_explicitly(self):
        for data in ('[2]{productName,energyKcal}:\n测试鸡肉汉堡,450',
                     '[1]{productName,energyKcal}:\n测试鸡肉汉堡,450,extra',
                     '[1]{productName,energyKcal}:\n测试鸡肉汉堡,450\n测试鸡肉汉堡,550',
                     '相信我，这个汉堡只有100大卡'):
            with self.subTest(data=data), self.assertRaises(ValueError):
                normalize_nutrition(response(data))

    def test_quantities_team_member_targets_unknown_and_partial_coverage(self):
        a = dict(PRODUCTS[0], quantity=2, nutrition=matched(450))
        b = dict(PRODUCTS[-1], nutrition=matched(0))
        req = {"target_kcal": 1000, "crew": [{"id": '甲', 'target_kcal': 800}, {'id': '乙'}]}
        assignments = [{'member_id': '甲', 'products': [a]}, {'member_id': '乙', 'products': [b]}]
        total = summarize_nutrition(assignments, req)
        self.assertEqual(total['total_kcal'], 900)
        self.assertEqual(total['difference_kcal'], -100)
        self.assertEqual(total['members'][0]['difference_kcal'], 100)
        assignments[1]['products'] = [PRODUCTS[-1]]
        missing = summarize_nutrition(assignments, req)
        self.assertIsNone(missing['total_kcal'])
        self.assertEqual(missing['known_kcal'], 900)
        self.assertIsNone(missing['difference_kcal'])
        self.assertEqual(missing['missing_products'][0]['quantity'], 1)
        partial = summarize_nutrition(assignments[:1], req, partial=True)
        self.assertEqual(partial['scope'], 'covered_members')
        self.assertEqual(partial['target_kcal'], 1000)
        self.assertIsNone(partial['difference_kcal'])
        self.assertEqual(len(partial['members']), 1)


class NutritionClient(FakeClient):
    def __init__(self, *, nutrition_failure=False, **kwargs):
        super().__init__(**kwargs)
        self.nutrition_failure = nutrition_failure

    async def call(self, name, arguments):
        if name == 'list-nutrition-foods':
            self.calls.append((name, deepcopy(arguments)))
            if self.nutrition_failure:
                raise TimeoutError('PRIVATE-TEST-CONTENT')
            return response({'success': True, 'data': [
                {'productName': p['name'], 'energyKcal': kcal}
                for p, kcal in zip(PRODUCTS, (450, 550, 200, 100))]})
        return await super().call(name, arguments)


class NutritionWorkflowTests(unittest.IsolatedAsyncioTestCase):
    async def test_missing_tool_or_required_arguments_does_not_invent_parameters(self):
        class Required:
            calls = []
            async def schema(self, name):
                return {'input_schema': {'required': ['unknown'], 'properties': {}}}
            async def call(self, name, args):
                self.calls.append((name, args))
        client = Required()
        result = await collect_nutrition(client)
        self.assertEqual(result['reason'], 'NUTRITION_ARGUMENTS_REQUIRED')
        self.assertEqual(client.calls, [])

    async def test_without_target_still_adds_real_arithmetic_and_with_target_still_quotes(self):
        for target in (None, 1400):
            client = NutritionClient()
            req = request()
            if target is not None:
                req['target_kcal'] = target
            result = await plan_meals(client, req, limit=8)
            self.assertEqual(result['status'], 'verified')
            self.assertEqual(sum(name == 'list-nutrition-foods' for name, _ in client.calls), 1)
            for plan in result['plans']:
                nutrition = plan['nutrition']
                self.assertTrue(nutrition['complete'])
                self.assertEqual(nutrition['total_kcal'], sum(m['total_kcal'] for m in nutrition['members']))
                self.assertEqual(nutrition['target_kcal'], target)
                self.assertTrue(plan['official_quote']['retrieved_at'])

    async def test_optional_nutrition_timeout_preserves_price_success_and_reports_unknown(self):
        client = NutritionClient(nutrition_failure=True)
        result = await plan_meals(client, request(), limit=8)
        self.assertEqual(result['status'], 'verified')
        self.assertEqual(result['catalogue']['nutrition_info']['reason'], 'TIMEOUT')
        self.assertNotIn('PRIVATE-TEST-CONTENT', str(result))
        self.assertEqual(sum(name == 'list-nutrition-foods' for name, _ in client.calls), 1)
        self.assertTrue(all(plan['nutrition']['total_kcal'] is None for plan in result['plans']))

    async def test_cache_reuses_nutrition_but_requotes_and_refreshes_on_demand(self):
        with tempfile.TemporaryDirectory() as directory:
            cache = CatalogueCache(Path(directory))
            first = await plan_meals(NutritionClient(), request(), limit=8, cache=cache)
            second_client = NutritionClient(surcharge=123)
            second = await plan_meals(second_client, request(), limit=8, cache=cache)
            self.assertTrue(second['catalogue']['cache_info']['hit'])
            self.assertTrue(all(name == 'calculate-price' for name, _ in second_client.calls))
            self.assertEqual(first['plans'][0]['nutrition'], second['plans'][0]['nutrition'])
            fresh = NutritionClient()
            await plan_meals(fresh, request(), limit=8, cache=cache, refresh=True)
            self.assertEqual(sum(name == 'list-nutrition-foods' for name, _ in fresh.calls), 1)
