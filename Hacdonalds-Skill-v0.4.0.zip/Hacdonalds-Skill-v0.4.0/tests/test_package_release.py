"""Release must include hidden host adapters and exclude private state."""

import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("release", ROOT / "scripts/package_release.py")
release = importlib.util.module_from_spec(spec)
spec.loader.exec_module(release)


class PackageTests(unittest.TestCase):
    def test_source_archive_keeps_adapters_and_excludes_credentials(self):
        with tempfile.TemporaryDirectory() as directory:
            root, output = Path(directory) / "源码", Path(directory) / "交付"
            for name, text in {
                "pyproject.toml": '[project]\nversion="0.2.0"\n',
                ".agents/skills/hacdonalds/SKILL.md": "codex",
                ".codebuddy/skills/hacdonalds/SKILL.md": "workbuddy",
                "src/main.py": "print('source')",
                ".env.example": "MCD_MCP_TOKEN=${MCD_MCP_TOKEN}",
                ".env": "PRIVATE_NO_EXPORT",
                ".local/credentials.json": "PRIVATE_NO_EXPORT",
                ".local/crew/state.json": "PRIVATE_NO_EXPORT",
                ".local/reports/meal.html": "PRIVATE_NO_EXPORT",
                ".git/config": "PRIVATE_NO_EXPORT",
                ".venv/secret": "PRIVATE_NO_EXPORT",
                "__pycache__/module.pyc": "PRIVATE_NO_EXPORT",
            }.items():
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(text, encoding="utf-8")
            path, checksum, count = release.package(root, output)
            self.assertEqual(count, 5)
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), checksum)
            with zipfile.ZipFile(path) as archive:
                names = archive.namelist()
                self.assertTrue(any(".codebuddy/" in name for name in names))
                self.assertTrue(any(".agents/" in name for name in names))
                self.assertFalse(any(".local/" in name or ".git/" in name for name in names))
                self.assertTrue(all(b"PRIVATE_NO_EXPORT" not in archive.read(name) for name in names))
                manifest = json.loads(archive.read("Hacdonalds-Skill-v0.2.0/FILE_SHA256.json"))
                for relative, expected in manifest.items():
                    self.assertEqual(hashlib.sha256(archive.read("Hacdonalds-Skill-v0.2.0/" + relative)).hexdigest(), expected)


if __name__ == "__main__":
    unittest.main()
