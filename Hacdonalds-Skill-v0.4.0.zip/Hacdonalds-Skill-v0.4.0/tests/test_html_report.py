"""Static meal attachment facts, escaping, scope and no client-side product UI."""

from copy import deepcopy
from html.parser import HTMLParser
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hacdonalds.explain import summarize
from hacdonalds.html_report import render_report
from test_explain import result_fixture
from test_calorie_explain import fixture


class Document(HTMLParser):
    def __init__(self, html):
        super().__init__(convert_charrefs=True)
        self.nodes = []
        self.text = []
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        self.nodes.append((tag, dict(attrs)))

    def handle_data(self, text):
        self.text.append(text)

    def elements(self, tag):
        return [attrs for actual, attrs in self.nodes if actual == tag]

    def cards(self):
        return [attrs for tag, attrs in self.nodes if tag == 'article' and attrs.get('class') == 'member']


class StaticReportTests(unittest.TestCase):
    def test_only_recommended_meal_and_official_amount_are_shown(self):
        summary = summarize(result_fixture())
        original = deepcopy(summary)
        html = render_report(summary, generated_at='2026-10-25T06:00:00+00:00')
        doc = Document(html)
        self.assertEqual(len(doc.cards()), 2)
        self.assertIn('25.01 元', html)
        self.assertIn('¥ 25.01', html)
        self.assertIn('¥ 24.99', html)
        self.assertNotIn('¥ 22.00', html)
        self.assertNotIn('¥ 30.00', html)
        self.assertNotIn('价格优先', html)
        self.assertNotIn('丰盛搭配', html)
        self.assertIn('测试鸡肉堡', html)
        self.assertIn('× 2', html)
        self.assertNotIn('49.99', html)
        self.assertEqual(summary, original)

    def test_one_static_page_has_no_script_navigation_or_history(self):
        summary = summarize(fixture())
        summary['history'] = {'revision': 1, 'notice': 'SHOULD_NOT_APPEAR', 'summary': summarize(result_fixture())}
        html = render_report(summary)
        doc = Document(html)
        for tag in ('script', 'nav', 'button', 'iframe', 'form', 'input', 'select', 'a', 'link', 'img'):
            self.assertEqual(doc.elements(tag), [], tag)
        self.assertNotIn('SHOULD_NOT_APPEAR', html)
        self.assertNotIn('方案对比', html)
        self.assertNotIn('历史方案', html)
        self.assertNotIn('shared', html)
        self.assertIn('@media print', html)
        self.assertIn("script-src 'none'", html)
        self.assertTrue(all(not key.startswith('on') for _, attrs in doc.nodes for key in attrs))

    def test_without_recommendation_first_plan_is_used_without_inventing_another(self):
        summary = summarize(result_fixture())
        summary['recommendation'] = None
        html = render_report(summary)
        self.assertIn('¥ 22.00', html)
        self.assertNotIn('¥ 25.01', html)
        self.assertEqual(len(Document(html).cards()), 2)
        summary['plans'] = summary['plans'][:1]
        self.assertEqual(len(Document(render_report(summary)).cards()), 2)

    def test_calories_quantities_targets_and_distinct_timestamps(self):
        result = fixture()
        result['plans'][0]['official_quote']['retrieved_at'] = '2026-10-25T04:30:00Z'
        for assignment in result['plans'][0]['assignments']:
            for product in assignment['products']:
                product['nutrition']['retrieved_at'] = '2026-10-24T05:00:00+00:00'
        html = render_report(summarize(result), generated_at='2026-10-25T06:00:00+00:00')
        for number in ('1750.4', '1200.4', '550', '1800', '49.6'):
            self.assertIn(number, html)
        self.assertIn('低于目标 49.6 kcal', html)
        self.assertIn('2026-10-25 12:30:00 北京时间', html)
        self.assertIn('2026-10-24 13:00:00 北京时间', html)
        self.assertIn('2026-10-25 14:00:00 北京时间', html)
        self.assertEqual(len(Document(html).cards()), 2)

    def test_missing_calories_are_unknown_with_known_subtotal(self):
        result = fixture()
        result['plans'][0]['assignments'][1]['products'][0].pop('nutrition')
        html = render_report(summarize(result))
        self.assertIn('热量待核实', html)
        self.assertIn('已知小计 1200.4 kcal', html)
        self.assertIn('测试牛堡 × 1', html)
        self.assertNotIn('>1750.4', html)
        self.assertNotIn('>0<small>kcal', html)
        self.assertIn('暂不比较目标', html)

    def test_partial_result_uses_covered_scope_without_team_target_comparison(self):
        result = fixture()
        result['status'] = 'partial_verified'
        result['effective_request'] = deepcopy(result['request'])
        result['effective_request'].pop('target_kcal')
        result['effective_request']['budget_fen'] = 4000
        result['effective_request']['crew'] = result['effective_request']['crew'][:1]
        result['plans'][0]['assignments'] = result['plans'][0]['assignments'][:1]
        result['coverage'] = {'covered_member_ids': ['甲'], 'pending_member_ids': ['乙'],
                              'pending_dietary_member_ids': ['乙'], 'reserved_budget_fen': 1000,
                              'available_budget_fen': 4000}
        html = render_report(summarize(result))
        self.assertEqual(len(Document(html).cards()), 1)
        self.assertIn('已覆盖成员官方小计', html)
        self.assertIn('已覆盖成员热量小计', html)
        self.assertNotIn('全队总热量', html)
        self.assertIn('暂不比较全队目标', html)
        self.assertIn('不是消费', html)
        self.assertNotIn('599.6', html)

    def test_failed_and_noncurrent_records_do_not_show_previous_food_or_prices(self):
        summary = summarize(fixture())
        summary['current'] = False
        html = render_report(summary)
        self.assertEqual(Document(html).cards(), [])
        self.assertNotIn('测试鸡堡', html)
        self.assertNotIn('¥ 30.00', html)
        self.assertIn('保存记录与当前需求不一致', html)
        summary['status'] = 'failed'
        summary['current'] = True
        summary['history'] = {'summary': summarize(fixture()), 'revision': 1}
        summary['error'] = {'code': 'TIMEOUT', 'message': '连接未完成'}
        summary['recovery_options'] = [{'message': '保留原需求', 'next_step': '检查连接'}]
        html = render_report(summary)
        self.assertEqual(Document(html).cards(), [])
        self.assertIn('TIMEOUT', html)
        self.assertIn('检查连接', html)
        self.assertNotIn('测试鸡堡', html)

    def test_blocked_dietary_result_does_not_claim_any_member_is_done(self):
        summary = {'status': 'needs_dietary_verification', 'current': True, 'plans': [],
                   'budget_fen': 8000, 'store_code': '1234567',
                   'coverage': {'pending_dietary_member_ids': ['乙'], 'covered_member_ids': [],
                                'pending_member_ids': ['甲', '乙'], 'reserved_budget_fen': 0,
                                'available_budget_fen': 8000}}
        html = render_report(summary)
        self.assertNotIn('仅部分成员完成配餐', html)
        self.assertIn('全队配餐尚未完成', html)
        self.assertEqual(Document(html).cards(), [])

    def test_dynamic_strings_are_escaped_and_never_create_executable_elements(self):
        attack = '</h2><script>alert(1)</script><img src=x onerror=alert(2)>'
        summary = summarize(fixture())
        plan = summary['plans'][0]
        plan['strategy_name'] = attack
        plan['assignments'][0]['member_id'] = attack
        plan['assignments'][0]['products'][0]['name'] = attack
        plan['assignments'][0]['preferences'] = {'matched': [attack], 'unmatched': [attack]}
        summary['store_code'] = attack
        html = render_report(summary, generated_at=attack)
        doc = Document(html)
        self.assertEqual(doc.elements('script'), [])
        self.assertEqual(doc.elements('img'), [])
        self.assertTrue(all(not key.startswith('on') for _, attrs in doc.nodes for key in attrs))
        self.assertNotIn(attack, html)
        self.assertIn('&lt;script&gt;alert(1)&lt;/script&gt;', html)
        self.assertIn(attack, ''.join(doc.text))


if __name__ == '__main__':
    unittest.main()
