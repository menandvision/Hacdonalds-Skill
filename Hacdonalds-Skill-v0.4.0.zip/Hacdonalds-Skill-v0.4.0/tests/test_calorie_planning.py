"""Optional meal-energy targets use synthetic products, never dietary advice."""

from copy import deepcopy
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import AsyncMock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hacdonalds.crew import apply_changes, request_diff, revise_crew, start_crew
from hacdonalds.errors import HacdonaldsError
from hacdonalds.partial import prepare_request, plan_with_reservations
from hacdonalds.planning import parse_request, propose
from hacdonalds.sessions import CrewSessionStore


def meal_request(**extra):
    return parse_request({"store_code": "1234567", "budget_fen": 5000,
                          "crew": [{"id": "甲", "drink": "none"}], **extra})


def food(code, kcal, *, cost=1000, role="main"):
    return {"code": code, "name": f"合成{code}汉堡", "role": role,
            "reference_price_fen": cost,
            "nutrition": {"status": "matched" if kcal is not None else "unknown", "kcal_per_item": kcal, "basis": "per_item"}}


def selected(result, strategy="saver"):
    return next(c for c in result["candidates"] if c["strategy"] == strategy)


class CalorieRequestTests(unittest.TestCase):
    def test_omitted_and_null_targets_do_not_change_legacy_request(self):
        before = meal_request()
        self.assertNotIn("target_kcal", before)
        self.assertNotIn("target_kcal", before["crew"][0])
        raw = deepcopy(before)
        raw["target_kcal"] = None
        raw["crew"][0]["target_kcal"] = None
        self.assertEqual(parse_request(raw), before)

    def test_targets_are_optional_positive_integer_kcal_and_bounded(self):
        for value in (True, False, 0, -1, 1.5, "600", 100001):
            with self.subTest(team=value), self.assertRaises(HacdonaldsError):
                meal_request(target_kcal=value)
        for value in (True, 0, -1, 1.5, "600", 10001):
            raw = meal_request()
            raw["crew"][0]["target_kcal"] = value
            with self.subTest(member=value), self.assertRaises(HacdonaldsError):
                parse_request(raw)
        self.assertEqual(meal_request(target_kcal=100000)["target_kcal"], 100000)
        raw = meal_request()
        raw["crew"][0]["target_kcal"] = 10000
        self.assertEqual(parse_request(raw)["crew"][0]["target_kcal"], 10000)

    def test_revisions_add_change_clear_targets_and_preserve_unmentioned_needs(self):
        before = meal_request()
        after = apply_changes(before, {"target_kcal": 1200,
            "member_updates": [{"id": "甲", "target_kcal": 650}],
            "add_members": [{"id": "乙", "target_kcal": 550, "prefer": ["辣"]}]})
        self.assertEqual(before, meal_request())
        self.assertEqual(after["target_kcal"], 1200)
        self.assertEqual(after["crew"][0]["drink"], "none")
        diff = request_diff(before, after)
        self.assertEqual(diff["fields"]["target_kcal"], {"before": None, "after": 1200})
        self.assertEqual(diff["member_updates"][0]["fields"]["target_kcal"], {"before": None, "after": 650})
        changed = apply_changes(after, {"member_updates": [{"id": "甲", "target_kcal": 700}]})
        self.assertEqual(changed["target_kcal"], 1200)
        self.assertEqual(changed["crew"][1]["target_kcal"], 550)
        cleared = apply_changes(changed, {"target_kcal": None,
            "member_updates": [{"id": "甲", "target_kcal": None}], "remove_member_ids": ["乙"]})
        self.assertEqual(cleared, before)
        cleared_diff = request_diff(changed, cleared)
        self.assertEqual(cleared_diff["fields"]["target_kcal"]["after"], None)

    def test_partial_request_keeps_full_team_target_without_implicit_allocation(self):
        raw = meal_request(target_kcal=1400)
        raw["crew"][0]["target_kcal"] = 600
        raw["crew"].append({"id": "乙", "target_kcal": 800, "avoid": ["不吃辣"]})
        prepared = prepare_request(raw, {"乙": 2000})
        self.assertEqual(prepared["request"]["target_kcal"], 1400)
        self.assertNotIn("target_kcal", prepared["effective_request"])
        self.assertEqual(prepared["effective_request"]["crew"][0]["target_kcal"], 600)
        self.assertEqual(prepared["request"]["crew"][1]["target_kcal"], 800)
        self.assertEqual(prepared["request"]["crew"][1]["avoid"], ["不吃辣"])
        self.assertEqual(prepared["effective_request"]["budget_fen"], 3000)


class CalorieSearchTests(unittest.TestCase):
    def test_unset_target_preserves_original_candidates_even_with_nutrition(self):
        products = [food("A", 400), food("B", 700, cost=1100), food("S", 250, cost=300, role="side")]
        raw = meal_request()
        without = [{k: v for k, v in p.items() if k != "nutrition"} for p in products]
        self.assertEqual(propose(raw, products), propose(raw, without))

    def test_team_target_changes_selection_without_becoming_an_upper_limit(self):
        products = [food("A", 300, cost=500), food("B", 650, cost=1000)]
        self.assertEqual(selected(propose(meal_request(), products))["assignments"][0]["codes"], ("A",))
        target = selected(propose(meal_request(target_kcal=600), products))
        self.assertEqual(target["assignments"][0]["codes"], ("B",))
        self.assertLessEqual(target["reference_total_fen"], 5000)

    def test_each_members_target_affects_own_assignment(self):
        raw = meal_request()
        raw["crew"][0]["target_kcal"] = 300
        raw["crew"].append({"id": "乙", "drink": "none", "target_kcal": 700})
        raw = parse_request(raw)
        plan = selected(propose(raw, [food("A", 300), food("B", 700)]))
        self.assertEqual([a["codes"] for a in plan["assignments"]], [("A",), ("B",)])

    def test_team_target_is_for_full_basket_not_each_member(self):
        raw = meal_request(target_kcal=1000)
        raw["crew"].append({"id": "乙", "drink": "none"})
        raw = parse_request(raw)
        products = [food("A", 300), food("B", 700), food("C", 1000)]
        plan = selected(propose(raw, products))
        by_code = {p["code"]: p["nutrition"]["kcal_per_item"] for p in products}
        self.assertEqual(sum(by_code[c] for a in plan["assignments"] for c in a["codes"]), 1000)

    def test_known_complete_energy_is_preferred_to_missing_not_treated_as_zero(self):
        products = [food("UNKNOWN", None, cost=100), food("KNOWN", 500, cost=1000)]
        plan = selected(propose(meal_request(target_kcal=50), products))
        self.assertEqual(plan["assignments"][0]["codes"], ("KNOWN",))
        all_missing = propose(meal_request(target_kcal=600), products[:1])
        self.assertTrue(all_missing["candidates"])

    def test_energy_targets_never_relax_hard_meal_and_budget_constraints(self):
        raw = meal_request(target_kcal=700)
        raw["budget_fen"] = 1500
        raw["crew"][0].update(hunger=4, drink="required", exclude_keywords=["排除"])
        products = [food("A", 300, cost=500), food("S", 200, cost=300, role="side"),
                    food("D", 100, cost=200, role="drink"), food("排除", 400, cost=500),
                    food("TOO_EXPENSIVE", 400, cost=5000)]
        plans = propose(parse_request(raw), products)["candidates"]
        self.assertTrue(plans)
        for plan in plans:
            self.assertLessEqual(plan["reference_total_fen"], 1500)
            codes = plan["assignments"][0]["codes"]
            self.assertIn("S", codes)
            self.assertIn("D", codes)
            self.assertNotIn("排除", codes)
            self.assertNotIn("TOO_EXPENSIVE", codes)

    def test_target_candidates_not_lost_to_original_price_and_preference_cutoffs(self):
        products = ([food(f"M{i}", 200 + i * 100, cost=1000 + i) for i in range(3)]
                    + [food(f"S{i}", 200 + i * 20, cost=500 + i, role="side") for i in range(5)]
                    + [food(f"D{i}", 100 + i * 30, cost=300 + i, role="drink") for i in range(5)])
        raw = meal_request()
        raw["crew"][0].update(target_kcal=900, drink="optional")
        plan = selected(propose(raw, products))
        self.assertEqual(plan["assignments"][0]["codes"], ("M2", "S4", "D4"))


class CalorieSessionTests(unittest.IsolatedAsyncioTestCase):
    async def test_partial_result_nutrition_is_scoped_and_keeps_original_target(self):
        raw = meal_request(target_kcal=1400)
        raw["crew"][0]["target_kcal"] = 600
        raw["crew"].append({"id": "乙", "target_kcal": 800, "avoid": ["不吃辣"]})
        async def planner(request, *, limit):
            self.assertNotIn("target_kcal", request)
            return {"status": "verified", "request": request, "plans": [{"strategy": "saver",
                "official_quote": {"amount_fen": 1000},
                "assignments": [{"member_id": "甲", "products": [food("A", 650)]}]}]}
        result = await plan_with_reservations(raw, planner, reservations_fen={"乙": 2000})
        self.assertEqual(result["status"], "partial_verified")
        nutrition = result["plans"][0]["nutrition"]
        self.assertEqual(nutrition["scope"], "covered_members")
        self.assertEqual(nutrition["target_kcal"], 1400)
        self.assertIsNone(nutrition["difference_kcal"])
        self.assertEqual(nutrition["total_kcal"], 650)
        self.assertEqual(nutrition["members"][0]["difference_kcal"], 50)

    async def test_invalid_target_is_rejected_before_planner_or_state_write(self):
        with tempfile.TemporaryDirectory() as directory:
            store = CrewSessionStore(Path(directory))
            planner = AsyncMock()
            raw = meal_request()
            raw["target_kcal"] = True
            with self.assertRaises(HacdonaldsError):
                await start_crew(store, raw, planner)
            planner.assert_not_called()
            self.assertFalse(store.directory.exists())

    async def test_calorie_dry_run_preserves_version_and_does_not_call_planner(self):
        with tempfile.TemporaryDirectory() as directory:
            store = CrewSessionStore(Path(directory))
            async def planner(request, *, limit):
                return {"status": "no_verified_plan", "request": request, "plans": []}
            state = await start_crew(store, meal_request(), planner)
            plan = AsyncMock()
            result = await revise_crew(store, state["session_id"], 1,
                {"target_kcal": 800, "member_updates": [{"id": "甲", "target_kcal": 800}]}, plan, dry_run=True)
            self.assertEqual(result["request"]["target_kcal"], 800)
            self.assertEqual(result["proposed_revision"], 2)
            self.assertFalse(result["network_called"])
            plan.assert_not_called()
            self.assertEqual(store.load(state["session_id"])["revision"], 1)
            self.assertNotIn("target_kcal", store.load(state["session_id"])["request"])


if __name__ == "__main__":
    unittest.main()
