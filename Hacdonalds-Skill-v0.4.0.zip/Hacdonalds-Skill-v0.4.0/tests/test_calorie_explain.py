"""Synthetic nutrition fixtures exercise summaries; no live data or requests."""

from copy import deepcopy
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hacdonalds.explain import render_text, request_change_lines, summarize


def product(code, name, kcal):
    return {"code": code, "name": name, "nutrition": {
        "status": "matched", "basis": "per_item", "kcal_per_item": kcal,
        "source": "list-nutrition-foods", "retrieved_at": "nutrition-original-time"}}


def fixture(*, target=True):
    request = {"store_code": "1234567", "budget_fen": 5000, "crew": [
        {"id": "甲", "prefer": [], "target_kcal": 1200},
        {"id": "乙", "prefer": [], "target_kcal": 550}]}
    if target:
        request["target_kcal"] = 1800
    a, s, b = product("A", "测试鸡堡", 480.2), product("S", "测试薯条", 240), product("B", "测试牛堡", 550)
    return {"status": "verified", "request": request, "plans": [{
        "strategy": "balanced", "official_quote": {"amount_fen": 3000, "retrieved_at": "quote-original-time"},
        "assignments": [{"member_id": "甲", "products": [a, deepcopy(a), s]},
                        {"member_id": "乙", "products": [b]}]}]}


class CalorieExplainTests(unittest.TestCase):
    def test_full_team_and_members_use_quantities_and_show_target_difference(self):
        result = fixture()
        original = deepcopy(result)
        summary = summarize(result)
        plan = summary["plans"][0]
        self.assertEqual(plan["nutrition"]["total_kcal"], 1750.4)
        self.assertEqual(plan["nutrition"]["difference_kcal"], -49.6)
        self.assertEqual(plan["assignments"][0]["nutrition"]["total_kcal"], 1200.4)
        text = render_text(summary)
        for phrase in ("全队总热量：1750.4 kcal", "低于目标 49.6 kcal", "餐食热量：1200.4 kcal", "高于目标 0.4 kcal", "与目标一致"):
            self.assertIn(phrase, text)
        self.assertEqual(result, original)

    def test_omitted_targets_still_display_calories(self):
        result = fixture(target=False)
        for member in result["request"]["crew"]:
            member.pop("target_kcal")
        summary = summarize(result)
        self.assertIsNone(summary["plans"][0]["nutrition"]["target_kcal"])
        self.assertIn("全队总热量：1750.4 kcal", render_text(summary))
        self.assertNotIn("本次餐食目标", render_text(summary))

    def test_unknown_product_is_named_and_not_reported_as_zero_or_complete(self):
        result = fixture()
        result["plans"][0]["assignments"][1]["products"][0].pop("nutrition")
        summary = summarize(result)
        nutrition = summary["plans"][0]["nutrition"]
        self.assertIsNone(nutrition["total_kcal"])
        self.assertIsNone(nutrition["difference_kcal"])
        self.assertEqual(nutrition["known_kcal"], 1200.4)
        self.assertFalse(summary["plans"][0]["assignments"][1]["nutrition"]["complete"])
        text = render_text(summary)
        self.assertIn("全队总热量：未完整；已知小计 1200.4 kcal", text)
        self.assertIn("待核实餐品：测试牛堡 × 1", text)
        self.assertIn("暂不比较目标", text)
        self.assertNotIn("餐食热量：0 kcal", text)

    def test_partial_plan_preserves_team_goal_without_calling_subtotal_team_total(self):
        result = fixture()
        result["status"] = "partial_verified"
        result["effective_request"] = deepcopy(result["request"])
        result["effective_request"].pop("target_kcal")
        result["effective_request"]["budget_fen"] = 4000
        result["effective_request"]["crew"] = result["effective_request"]["crew"][:1]
        result["plans"][0]["assignments"] = result["plans"][0]["assignments"][:1]
        result["coverage"] = {"pending_dietary_member_ids": ["乙"], "covered_member_ids": ["甲"],
                              "pending_member_ids": ["乙"], "reserved_budget_fen": 1000, "available_budget_fen": 4000}
        summary = summarize(result)
        nutrition = summary["plans"][0]["nutrition"]
        self.assertEqual(nutrition["scope"], "covered_members")
        self.assertEqual(nutrition["target_kcal"], 1800)
        self.assertIsNone(nutrition["difference_kcal"])
        text = render_text(summary)
        self.assertIn("已覆盖成员热量小计：1200.4 kcal", text)
        self.assertIn("暂不比较全队目标", text)
        self.assertNotIn("全队总热量：", text)
        self.assertNotIn("低于目标 599.6", text)

    def test_original_nutrition_time_remains_distinct_from_quote_time(self):
        result = fixture()
        text = render_text(summarize(result))
        self.assertIn("营养数据时间：nutrition-original-time", text)
        self.assertIn("核价时间：quote-original-time", text)
        self.assertNotIn("营养数据时间：quote-original-time", text)

    def test_historical_plan_keeps_original_target_and_nutrition_time(self):
        historical = fixture()
        current_request = deepcopy(historical["request"])
        current_request["target_kcal"] = 2000
        state = {"status": "failed", "session_id": "a" * 32, "revision": 2,
                 "request": current_request, "view_only": True, "last_verified_is_current": False,
                 "last_attempt": {"revision": 2, "status": "failed", "result": {
                     "status": "failed", "request": current_request, "plans": []}},
                 "last_verified": {"revision": 1, "result": historical}}
        summary = summarize(state, crew=True)
        self.assertEqual(summary["plans"], [])
        old = summary["history"]["summary"]["plans"][0]["nutrition"]
        self.assertEqual(old["target_kcal"], 1800)
        self.assertEqual(old["retrieved_at"], ["nutrition-original-time"])
        text = render_text(summary)
        self.assertIn("历史方案（revision 1，非当前）", text)
        self.assertIn("查看未重新核价；本次未联网", text)
        self.assertIn("营养数据时间：nutrition-original-time", text)
        self.assertNotIn("目标 2000 kcal", text)

    def test_team_and_member_target_changes_have_units_and_clear_notice(self):
        lines = request_change_lines({"fields": {"target_kcal": {"before": 1800, "after": None}},
            "member_updates": [{"id": "甲", "fields": {"target_kcal": {"before": None, "after": 700}}}]})
        self.assertIn("目标热量：1800 kcal（本次餐食，尽量接近） → 未设置", lines)
        self.assertIn("成员 甲 目标热量：未设置 → 700 kcal（本次餐食，尽量接近）", lines)


if __name__ == "__main__":
    unittest.main()
