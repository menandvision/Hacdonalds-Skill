"""Automatic report side effects use isolated folders and synthetic quotes."""
from contextlib import redirect_stderr, redirect_stdout
from copy import deepcopy
from datetime import datetime, timezone, timedelta
from io import StringIO
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, patch

from hacdonalds.cli import main
from hacdonalds.errors import HacdonaldsError
from hacdonalds.explain import summarize
from hacdonalds.reporting import attach_report, write_report
from test_explain import result_fixture, crew_fixture


class ReportWriterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='报告 测试 ')
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def test_unique_unicode_paths_and_metadata_match_written_files(self):
        summary = summarize(result_fixture())
        first = write_report(self.root, summary)
        second = write_report(self.root, summary)
        self.assertEqual(first['status'], 'written')
        self.assertEqual(second['status'], 'written')
        self.assertNotEqual(first['path'], second['path'])
        for metadata in (first, second):
            path = Path(metadata['path'])
            self.assertTrue(path.is_absolute())
            self.assertTrue(path.is_relative_to(self.root / '.local' / 'reports'))
            self.assertIn('测试鸡肉堡', path.read_text(encoding='utf-8'))
            self.assertEqual(datetime.fromisoformat(metadata['generated_at']).utcoffset(), timedelta(hours=8))
        self.assertEqual(len(list((self.root / '.local' / 'reports').glob('*.html'))), 2)
        self.assertFalse(list((self.root / '.local' / 'reports').glob('*.tmp')))

    def test_explicit_token_and_bearer_are_removed_before_rendering(self):
        result = result_fixture()
        for plan in result['plans']:
            plan['assignments'][0]['products'][0]['name'] = 'PRIVATE-REPORT-TOKEN Bearer OTHER-PRIVATE'
        metadata = write_report(self.root, summarize(result), token='PRIVATE-REPORT-TOKEN')
        content = Path(metadata['path']).read_text(encoding='utf-8')
        self.assertNotIn('PRIVATE-REPORT-TOKEN', content)
        self.assertNotIn('OTHER-PRIVATE', content)
        self.assertIn('REDACTED', content)

    def test_disk_failure_preserves_no_partial_files_and_reveals_no_exception(self):
        with patch('hacdonalds.reporting.os.replace', side_effect=OSError('PRIVATE-FILESYSTEM-DATA')):
            metadata = write_report(self.root, summarize(result_fixture()))
        self.assertEqual(metadata['status'], 'failed')
        self.assertEqual(metadata['code'], 'REPORT_WRITE_FAILED')
        self.assertNotIn('PRIVATE-FILESYSTEM-DATA', str(metadata))
        self.assertFalse(list((self.root / '.local' / 'reports').iterdir()))

    def test_name_collision_cannot_overwrite_an_old_export(self):
        fixed = datetime(2026, 10, 25, 14, 0, tzinfo=timezone(timedelta(hours=8)))
        with patch('hacdonalds.reporting.datetime') as clock, patch('hacdonalds.reporting.uuid4', return_value=SimpleNamespace(hex='a' * 32)):
            clock.now.return_value = fixed
            first = write_report(self.root, summarize(result_fixture()))
            content = Path(first['path']).read_bytes()
            second = write_report(self.root, summarize(result_fixture()))
        self.assertEqual(second['status'], 'failed')
        self.assertEqual(Path(first['path']).read_bytes(), content)
        self.assertEqual(len(list((self.root / '.local' / 'reports').glob('*.html'))), 1)

    def test_invalid_kind_and_blocked_directory_return_safe_failure(self):
        summary = summarize(result_fixture())
        self.assertEqual(write_report(self.root, summary, kind='../escape')['status'], 'failed')
        self.assertFalse((self.root / '.local').exists())
        (self.root / '.local').mkdir()
        (self.root / '.local' / 'reports').write_text('occupied', encoding='utf-8')
        self.assertEqual(write_report(self.root, summary)['status'], 'failed')
        self.assertEqual((self.root / '.local' / 'reports').read_text(encoding='utf-8'), 'occupied')

    def test_attach_report_skips_dry_run_and_view_only_without_any_writes(self):
        for result in ({'status': 'dry_run'}, {'status': 'verified', 'view_only': True},
                       {'status': 'failed'}, {'status': 'needs_dietary_verification'},
                       {'status': 'verified', 'summary': {'current': False, 'plans': [1]}},
                       {'status': 'verified', 'summary': {'current': True, 'plans': []}}):
            self.assertEqual(attach_report(result, self.root), result)
        self.assertFalse((self.root / '.local').exists())


class ReportCLITests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='自动 报告 ')
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.request_path = self.root / 'request.json'
        self.request_path.write_text(json.dumps(result_fixture()['request']), encoding='utf-8')

    def invoke_plan(self, *extra, fixture=None):
        with (patch('hacdonalds.cli.load_settings', return_value=SimpleNamespace(token='PRIVATE')),
              patch('hacdonalds.cli.run_live', new=AsyncMock(return_value=fixture or result_fixture())),
              redirect_stdout(StringIO()) as out):
            code = main(['plan', '--request', str(self.request_path), *extra], root=self.root)
        return code, out.getvalue()

    def test_plan_default_json_and_saved_json_include_existing_html(self):
        destination = self.root / 'plan.json'
        code, output = self.invoke_plan('--output', str(destination))
        self.assertEqual(code, 0)
        result = json.loads(output)
        self.assertEqual(result, json.loads(destination.read_text(encoding='utf-8')))
        self.assertEqual(result['report']['status'], 'written')
        self.assertTrue(Path(result['report']['path']).is_file())
        self.assertEqual(result['summary']['recommendation']['strategy'], 'balanced')

    def test_text_output_includes_the_report_path(self):
        code, output = self.invoke_plan('--format', 'text')
        self.assertEqual(code, 0)
        path = next((self.root / '.local' / 'reports').glob('*.html'))
        self.assertIn(str(path), output)
        self.assertIn('HTML配餐报告', output)

    def test_formal_crew_start_and_revision_each_export_a_distinct_report(self):
        state = crew_fixture(result_fixture())
        with patch('hacdonalds.cli.run_crew', new=AsyncMock(return_value=state)), redirect_stdout(StringIO()) as out:
            first_code = main(['crew', 'start', '--request', str(self.request_path)], root=self.root)
        first = json.loads(out.getvalue())
        with patch('hacdonalds.cli.run_crew', new=AsyncMock(return_value=state)), redirect_stdout(StringIO()) as out:
            second_code = main(['crew', 'revise', '--session', state['session_id'], '--expected-revision', '2', '--refresh'], root=self.root)
        second = json.loads(out.getvalue())
        self.assertEqual((first_code, second_code), (0, 0))
        self.assertNotEqual(first['report']['path'], second['report']['path'])
        self.assertIn('crew-start', first['report']['path'])
        self.assertIn('crew-revise', second['report']['path'])
        self.assertTrue(Path(first['report']['path']).is_file())
        self.assertTrue(Path(second['report']['path']).is_file())

    def test_dry_run_and_show_do_not_export(self):
        with redirect_stdout(StringIO()) as out:
            self.assertEqual(main(['crew', 'start', '--request', str(self.request_path), '--dry-run'], root=self.root), 0)
        self.assertNotIn('report', json.loads(out.getvalue()))
        state = crew_fixture(result_fixture())
        with patch('hacdonalds.cli.run_crew', new=AsyncMock(return_value=state)), redirect_stdout(StringIO()) as out:
            self.assertEqual(main(['crew', 'show', '--session', state['session_id']], root=self.root), 0)
        self.assertNotIn('report', json.loads(out.getvalue()))
        self.assertFalse((self.root / '.local').exists())

    def test_writer_failure_does_not_change_verified_business_result(self):
        failure = {'status': 'failed', 'code': 'REPORT_WRITE_FAILED', 'message': '报告保存失败，配餐结果仍保留。'}
        with patch('hacdonalds.reporting.write_report', return_value=failure):
            code, output = self.invoke_plan()
        payload = json.loads(output)
        self.assertEqual(code, 0)
        self.assertEqual(payload['status'], 'verified')
        self.assertEqual(payload['report'], failure)
        with patch('hacdonalds.reporting.write_report', return_value=failure):
            code, text = self.invoke_plan('--format', 'text')
        self.assertEqual(code, 0)
        self.assertIn(failure['message'], text)

    def test_plan_error_keeps_stderr_contract_without_creating_an_attachment(self):
        with (patch('hacdonalds.cli.load_settings', side_effect=HacdonaldsError('TOKEN_MISSING', '尚未配置凭证')),
              redirect_stderr(StringIO()) as err, redirect_stdout(StringIO()) as out):
            code = main(['plan', '--request', str(self.request_path)], root=self.root)
        self.assertEqual(code, 2)
        self.assertEqual(out.getvalue(), '')
        error = json.loads(err.getvalue())
        self.assertFalse(error['ok'])
        self.assertEqual(error['code'], 'TOKEN_MISSING')
        self.assertNotIn('report', error)
        self.assertFalse((self.root / '.local').exists())

    def test_failed_revision_with_history_does_not_export_a_meal_attachment(self):
        state = crew_fixture(result_fixture(), result_fixture())
        state['status'] = 'failed'
        state['last_attempt'] = {'revision': 2, 'status': 'failed',
                                 'error': {'code': 'TIMEOUT', 'message': '本轮超时，需求已保留'}}
        with patch('hacdonalds.cli.run_crew', new=AsyncMock(return_value=state)), redirect_stdout(StringIO()) as out:
            code = main(['crew', 'revise', '--session', state['session_id'], '--expected-revision', '2', '--refresh'], root=self.root)
        payload = json.loads(out.getvalue())
        self.assertEqual(code, 2)
        self.assertEqual(payload['summary']['plans'], [])
        self.assertIsNone(payload['summary']['recommendation'])
        self.assertEqual(payload['summary']['history']['revision'], 1)
        self.assertNotIn('report', payload)
        self.assertFalse((self.root / '.local').exists())

    def test_invalid_request_has_zero_report_writes(self):
        self.request_path.write_text('{"store_code":"123","budget_fen":true,"crew":[]}', encoding='utf-8')
        with patch('hacdonalds.cli.load_settings') as credentials, redirect_stderr(StringIO()):
            self.assertEqual(main(['plan', '--request', str(self.request_path)], root=self.root), 2)
        credentials.assert_not_called()
        self.assertFalse((self.root / '.local').exists())

    def test_pending_dietary_confirmation_has_no_meal_attachment(self):
        req = result_fixture()['request']
        req['crew'][0]['avoid'] = ['不吃辣']
        self.request_path.write_text(json.dumps(req), encoding='utf-8')
        with patch('hacdonalds.cli.load_settings') as credentials, redirect_stdout(StringIO()) as out:
            code = main(['plan', '--request', str(self.request_path)], root=self.root)
        result = json.loads(out.getvalue())
        self.assertEqual(code, 2)
        self.assertEqual(result['status'], 'needs_dietary_verification')
        self.assertNotIn('report', result)
        self.assertFalse((self.root / '.local').exists())
        credentials.assert_not_called()
