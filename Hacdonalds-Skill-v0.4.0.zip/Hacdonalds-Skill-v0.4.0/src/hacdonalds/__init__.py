"""Hacdonald's MCP integration layer."""

__version__ = "0.4.0"
