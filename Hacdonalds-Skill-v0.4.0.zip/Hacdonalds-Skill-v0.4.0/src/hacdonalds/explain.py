"""Deterministic descriptions of workflow facts; no model or network calls."""

from collections import Counter

from .nutrition import summarize_nutrition


STRATEGY_NAMES = {"saver": "价格优先", "balanced": "均衡搭配", "full_power": "丰盛搭配"}
RECOMMENDATION_ORDER = ("balanced", "saver", "full_power")
STATUS_NAMES = {
    "verified": "已取得官方核价方案", "dry_run": "仅校验需求，未联网、未保存",
    "partial_verified": "仅部分成员已取得官方核价，团队需求尚未完成",
    "insufficient_unreserved_budget": "预留后没有可用于其余成员的预算",
    "needs_dietary_verification": "配料或过敏原禁忌尚待核实",
    "no_feasible_reference_plan": "当前采集范围内没有满足需求的参考方案",
    "no_verified_plan": "尚未取得满足预算的官方核价方案",
    "failed": "本轮执行失败", "cancelled": "本轮已取消", "pending": "本轮尚未完成",
}
FIELD_NAMES = {"store_code": "门店编码", "budget_fen": "总预算", "target_kcal": "目标热量", "hunger": "食量",
               "drink": "饮品要求", "prefer": "名称偏好", "exclude_keywords": "名称排除", "avoid": "配料或过敏原禁忌"}
DRINK_NAMES = {"none": "不要饮料", "required": "需要饮料", "optional": "饮料可选"}


def money(fen):
    if type(fen) is not int:
        return "未提供"
    sign = "-" if fen < 0 else ""
    return f"{sign}{abs(fen) // 100}.{abs(fen) % 100:02d} 元"


def strategy_name(strategy):
    return STRATEGY_NAMES.get(strategy, str(strategy))


def grouped_products(products):
    counts, names = Counter(), {}
    for product in products:
        code = product["code"]
        counts[code] += product.get("quantity", 1)
        names[code] = product.get("name", code)
    return [{"code": code, "name": names[code], "quantity": count} for code, count in sorted(counts.items())]


def product_text(products):
    return "、".join(f"{p['name']} × {p['quantity']}" for p in products) or "无"


def member_food_changes(before, after):
    old = {a["member_id"]: a["products"] for a in before}
    new = {a["member_id"]: a["products"] for a in after}
    changes = []
    for identity in sorted(old.keys() | new.keys()):
        previous = {p["code"]: p for p in old.get(identity, [])}
        current = {p["code"]: p for p in new.get(identity, [])}
        removed, added = [], []
        for code in sorted(previous.keys() | current.keys()):
            difference = current.get(code, {}).get("quantity", 0) - previous.get(code, {}).get("quantity", 0)
            if difference < 0:
                removed.append(dict(previous[code], quantity=-difference))
            elif difference > 0:
                added.append(dict(current[code], quantity=difference))
        if removed or added:
            changes.append({"member_id": identity, "removed": removed, "added": added})
    return changes


def _describe_plan(plan, request, *, nutrition_request=None, partial=False):
    quote = plan.get("official_quote", {})
    amount = quote.get("amount_fen")
    if type(amount) is not int or amount < 0 or not plan.get("assignments"):
        return None
    members = {m["id"]: m for m in request.get("crew", [])}
    nutrition = summarize_nutrition(plan["assignments"], nutrition_request or request, partial=partial)
    nutrition["retrieved_at"] = sorted({
        product.get("nutrition", {}).get("retrieved_at")
        for assignment in plan["assignments"] for product in assignment["products"]
        if isinstance(product.get("nutrition"), dict)
        and isinstance(product["nutrition"].get("retrieved_at"), str)
        and product["nutrition"]["retrieved_at"]
    })
    nutrition_members = {member["member_id"]: member for member in nutrition["members"]}
    assignments = []
    for assignment in plan["assignments"]:
        products = grouped_products(assignment["products"])
        preferences = members.get(assignment["member_id"], {}).get("prefer", [])
        matched = [word for word in preferences if any(word.casefold() in p["name"].casefold() for p in products)]
        assignments.append({"member_id": assignment["member_id"], "products": products,
                            "preferences": {"matched": matched, "unmatched": [word for word in preferences if word not in matched]},
                            "nutrition": nutrition_members[assignment["member_id"]]})
    budget = request.get("budget_fen")
    return {"strategy": plan["strategy"], "strategy_name": strategy_name(plan["strategy"]),
            "store_code": request.get("store_code"), "official_total_fen": amount,
            "remaining_budget_fen": budget - amount if type(budget) is int else None,
            "quoted_at": quote.get("retrieved_at"), "assignments": assignments, "nutrition": nutrition}


def summarize_plan(result, *, current=True):
    request = result.get("request", {})
    meal_request = result.get("effective_request") or request
    partial = bool((result.get("coverage") or {}).get("pending_dietary_member_ids"))
    plans, seen = [], set()
    for plan in result.get("plans", []):
        described = _describe_plan(plan, meal_request, nutrition_request=request, partial=partial)
        if described is None:
            continue
        basket = Counter()
        for assignment in described["assignments"]:
            basket.update({p["code"]: p["quantity"] for p in assignment["products"]})
        key = tuple(sorted(basket.items()))
        if key in seen:
            continue
        seen.add(key)
        plans.append(described)
    saver = next((p for p in plans if p["strategy"] == "saver"), None)
    for plan in plans:
        if saver is not None and plan is not saver:
            plan["comparison_to_saver"] = {
                "official_difference_fen": plan["official_total_fen"] - saver["official_total_fen"],
                "members": member_food_changes(saver["assignments"], plan["assignments"])}
    recommended = None
    if current and result.get("status") == "verified":
        for strategy in RECOMMENDATION_ORDER:
            chosen = next((p for p in plans if p["strategy"] == strategy and p["remaining_budget_fen"] is not None and p["remaining_budget_fen"] >= 0), None)
            if chosen:
                matched = sum(len(a["preferences"]["matched"]) for a in chosen["assignments"])
                portions = sum(p["quantity"] for a in chosen["assignments"] for p in a["products"])
                reason = f"当前方案命中 {matched} 项成员名称偏好，共 {portions} 份餐品，官方核价后余额 {money(chosen['remaining_budget_fen'])}。"
                if saver is not None:
                    reason += f"相比价格优先方案{_difference_text(chosen['official_total_fen'] - saver['official_total_fen'])}。"
                else:
                    reason += "当前未取得价格优先方案，无法比较实际差价。"
                recommended = {"strategy": strategy, "strategy_name": strategy_name(strategy),
                               "reason": reason}
                break
    return {"status": result.get("status", "unknown"), "current": current,
            "store_code": request.get("store_code"), "budget_fen": request.get("budget_fen"),
            "recommendation": recommended, "plans": plans, "coverage": result.get("coverage"),
            "reservations_fen": result.get("reservations_fen", {}),
            "recovery_options": result.get("recovery_options", [])}


def _field_value(field, value):
    if value is None:
        return "未设置"
    if field == "budget_fen":
        return money(value)
    if field == "target_kcal":
        return f"{value} kcal（本次餐食，尽量接近）"
    if field == "drink":
        return DRINK_NAMES.get(value, str(value))
    if isinstance(value, list):
        return "、".join(value) or "无"
    return str(value)


def request_change_lines(diff):
    lines = []
    for field, change in sorted(diff.get("fields", {}).items()):
        lines.append(f"{FIELD_NAMES.get(field, field)}：{_field_value(field, change['before'])} → {_field_value(field, change['after'])}")
    for update in diff.get("member_updates", []):
        for field, change in sorted(update["fields"].items()):
            lines.append(f"成员 {update['id']} {FIELD_NAMES.get(field, field)}：{_field_value(field, change['before'])} → {_field_value(field, change['after'])}")
    for member in diff.get("add_members", []):
        details = "；".join(f"{FIELD_NAMES[field]} {_field_value(field, member.get(field))}" for field in ("hunger", "drink", "prefer", "exclude_keywords", "avoid", "target_kcal"))
        lines.append(f"新增成员 {member['id']}：{details}")
    lines.extend(f"删除成员 {identity}" for identity in diff.get("remove_member_ids", []))
    return lines


def reservation_change_lines(diff):
    lines = []
    for identity, change in sorted(diff.items()):
        before = "未确认" if change["before"] is None else money(change["before"])
        after = "未确认（已清除）" if change["after"] is None else money(change["after"])
        lines.append(f"成员 {identity} 预留额：从 {before} 变为 {after}")
    return lines


def _difference_text(fen):
    if fen == 0:
        return "同价"
    return ("多花 " if fen > 0 else "少花 ") + money(abs(fen))


def _food_lines(changes):
    return [f"成员 {change['member_id']}：减少 {product_text(change.get('removed', []))}；增加 {product_text(change.get('added', []))}"
            for change in changes]


def food_change_lines(diff):
    if not diff.get("available"):
        reasons = {"NO_CURRENT_VERIFIED_PLAN": "本轮没有可比较的当前已核价方案", "NO_VERIFIED_BASELINE": "尚无上轮已核价方案可比较",
                   "COVERAGE_CHANGED": "新旧方案覆盖的成员不同，不比较官方金额增减"}
        return [reasons.get(diff.get("reason"), "尚无可用餐品差异")]
    lines = [f"与历史 revision {diff.get('baseline_revision')} 比较（历史金额不作为当前报价）："]
    for comparison in diff.get("comparisons", []):
        name, change = strategy_name(comparison["strategy"]), comparison["change"]
        if change in {"added", "removed"}:
            lines.append(f"{name}：{'新增本轮方案' if change == 'added' else '本轮未取得该方案'}")
        else:
            lines.append(f"{name}：{'逐人餐品未变' if change == 'same_food' else '逐人餐品有变化'}；官方总价{_difference_text(comparison['official_total_change_fen'])}")
            lines.extend(_food_lines(comparison.get("members", [])))
    return lines


def summarize(result, *, crew=False):
    if not crew:
        return summarize_plan(result)
    request = result.get("request", {})
    attempt = result.get("last_attempt", {})
    workflow = attempt.get("result", {"status": result.get("status"), "request": request, "plans": []})
    current = (attempt.get("revision") == result.get("revision") and workflow.get("request") == request
               and attempt.get("status") == result.get("status"))
    summary = summarize_plan(workflow, current=current)
    summary.update(status=result.get("status", "unknown"), store_code=request.get("store_code"),
                   budget_fen=request.get("budget_fen"), session_id=result.get("session_id"),
                   revision=result.get("revision"), proposed_revision=result.get("proposed_revision"),
                   request_changes=request_change_lines(result.get("request_diff", {})) + reservation_change_lines(result.get("reservation_diff", {})),
                   food_changes=food_change_lines(attempt.get("food_diff", {})), error=attempt.get("error"))
    summary["view_only"] = result.get("view_only", False)
    summary["coverage"] = workflow.get("coverage") or result.get("coverage")
    summary["reservations_fen"] = result.get("reservations_fen", workflow.get("reservations_fen", {}))
    summary["recovery_options"] = attempt.get("recovery_options", workflow.get("recovery_options", []))
    historical = result.get("last_verified")
    if historical and (historical.get("revision") != result.get("revision") or not result.get("last_verified_is_current")):
        summary["history"] = {"revision": historical.get("revision"),
                              "notice": "历史核价方案属于旧需求，不代表当前修改已成功，也不能作为当前报价。",
                              "summary": summarize_plan(historical.get("result", {}), current=False)}
    return summary



def _kcal(value):
    return f"{value:.1f}".rstrip("0").rstrip(".")


def _calorie_line(nutrition, label, *, partial=False):
    if nutrition.get("complete") and nutrition.get("total_kcal") is not None:
        text = f"{label}：{_kcal(nutrition['total_kcal'])} kcal（千卡）"
    else:
        missing = product_text(nutrition.get("missing_products", []))
        text = f"{label}：未完整；已知小计 {_kcal(nutrition.get('known_kcal', 0))} kcal；待核实餐品：{missing}"
    target = nutrition.get("target_kcal")
    if target is not None:
        text += f"；{'全队' if partial else '本次餐食'}目标 {_kcal(target)} kcal（尽量接近）"
        difference = nutrition.get("difference_kcal")
        if partial:
            text += "；仅覆盖部分成员，暂不比较全队目标"
        elif difference is None:
            text += "；数据未完整，暂不比较目标"
        elif difference == 0:
            text += "；与目标一致"
        else:
            text += f"；{'高于' if difference > 0 else '低于'}目标 {_kcal(abs(difference))} kcal"
    return text


def _plan_text(summary):
    lines = []
    partial = bool(summary.get("coverage", {}).get("pending_dietary_member_ids")) if summary.get("coverage") else False
    for plan in summary["plans"]:
        amount_label, balance_label = ("已覆盖成员官方小计", "预留后可用余额") if partial else ("官方总价", "余额")
        lines.extend([f"{plan['strategy_name']}：{amount_label} {money(plan['official_total_fen'])}；{balance_label} {money(plan['remaining_budget_fen'])}",
                      f"门店编码：{plan['store_code'] or '未提供'}；核价时间：{plan['quoted_at'] or '未提供'}"])
        nutrition = plan["nutrition"]
        lines.append(_calorie_line(nutrition, "已覆盖成员热量小计" if partial else "全队总热量", partial=partial))
        lines.append("营养数据时间：" + ("、".join(nutrition.get("retrieved_at", [])) or "未提供"))
        for assignment in plan["assignments"]:
            preferences = assignment["preferences"]
            preference_text = (f"满足 {'、'.join(preferences['matched']) or '无'}；未满足 {'、'.join(preferences['unmatched']) or '无'}"
                               if preferences["matched"] or preferences["unmatched"] else "未设置")
            lines.extend([f"  成员 {assignment['member_id']}：{product_text(assignment['products'])}",
                          f"  名称偏好：{preference_text}",
                          "  " + _calorie_line(assignment["nutrition"], "餐食热量")])
        comparison = plan.get("comparison_to_saver")
        if comparison:
            lines.append(f"  相比价格优先：{_difference_text(comparison['official_difference_fen'])}")
            lines.extend(f"  {line}" for line in (_food_lines(comparison["members"]) or ["逐人餐品相同"]))
        elif plan["strategy"] != "saver":
            lines.append("  当前未取得价格优先方案，无法比较差价和餐品差异。")
    return lines


def render_text(summary):
    status = summary["status"]
    lines = [f"状态：{STATUS_NAMES.get(status, '尚未标记为完整核价成功')}（{status}）",
             f"门店编码：{summary.get('store_code') or '未提供'}；总预算：{money(summary.get('budget_fen'))}"]
    if summary.get("view_only"):
        lines.append("已保存的核价记录，查看未重新核价；本次未联网。")
    if summary.get("session_id"):
        lines.append(f"团队会话：{summary['session_id']}；revision：{summary.get('revision') or summary.get('proposed_revision')}")
    if summary.get("error"):
        error = summary["error"]
        lines.append(f"本轮错误：[{error['code']}] {error['message']}")
    coverage = summary.get("coverage")
    if coverage and coverage.get("pending_dietary_member_ids"):
        lines.extend([f"仅规划部分成员：已覆盖 {'、'.join(coverage['covered_member_ids']) or '无'}；待覆盖 {'、'.join(coverage['pending_member_ids']) or '无'}。",
                      f"禁忌成员预留 {money(coverage['reserved_budget_fen'])}（不是实际消费）；其余成员可用预算 {money(coverage['available_budget_fen'])}。",
                      "禁忌要求仍保留，预留预算不代表已完成禁忌成员的配餐。"])
        reservations = summary.get("reservations_fen", {})
        if reservations:
            lines.append("已确认预留：" + "；".join(f"{identity} {money(amount)}" for identity, amount in reservations.items()))
    if "request_changes" in summary:
        lines.append("需求差异：")
        lines.extend(f"  {line}" for line in (summary["request_changes"] or ["无需求变化记录"]))
        lines.append("餐品差异：")
        lines.extend(f"  {line}" for line in summary["food_changes"])
    recommended = summary["recommendation"]
    label = "推荐（基于已保存的核价记录）" if summary.get("view_only") else "推荐"
    lines.append(f"{label}：{recommended['strategy_name']}。{recommended['reason']}" if recommended else "当前没有可推荐的完整已核价方案。")
    lines.extend(_plan_text(summary))
    if summary.get("history"):
        history = summary["history"]
        lines.extend([f"历史方案（revision {history['revision']}，非当前）：", history["notice"]])
        lines.extend(_plan_text(history["summary"]))
    if summary["plans"] or summary.get("history"):
        lines.append("名称偏好只按餐名匹配；方案搜索限于本次采集的单品范围。")
        lines.append("热量按已匹配的官方每份营养数据和数量计算，供参考；缺失数据不按零计，热量目标不作为硬上限。")
    for option in summary.get("recovery_options", []):
        lines.append(f"恢复建议：{option['message']}")
        if type(option.get("minimum_reference_fen")) is int:
            lines.append(f"采集范围内参考最低金额 {money(option['minimum_reference_fen'])}；可用预算 {money(option.get('available_budget_fen'))}；参考差额 {money(option.get('reference_shortfall_fen'))}。")
        lines.append(f"下一步：{option['next_step']}")
    return "\n".join(lines)
