"""Validated crew revisions, separate current needs and historical quotes."""

import asyncio
from collections import Counter
from copy import deepcopy

from .errors import HacdonaldsError, public_error
from .planning import parse_request
from .partial import plan_with_reservations, prepare_request
from .privacy import redact
from .recovery import recovery_options
from .sessions import timestamp

MEMBER_FIELDS = {"hunger", "drink", "prefer", "exclude_keywords", "avoid", "target_kcal"}
CHANGE_FIELDS = {"budget_fen", "target_kcal", "member_updates", "add_members", "remove_member_ids"}


def apply_changes(raw_request, changes, *, allow_no_change=False):
    request = deepcopy(parse_request(raw_request))
    if not isinstance(changes, dict) or (not changes and not allow_no_change) or set(changes) - CHANGE_FIELDS:
        raise HacdonaldsError("INVALID_CHANGES", "修改仅支持 budget_fen、target_kcal、member_updates、add_members、remove_member_ids；换门店请新建团队。")
    updates = changes.get("member_updates", [])
    additions = changes.get("add_members", [])
    removals = changes.get("remove_member_ids", [])
    if not all(isinstance(items, list) for items in (updates, additions, removals)):
        raise HacdonaldsError("INVALID_CHANGES", "成员修改、新增和删除必须使用数组。")
    if any(not isinstance(identity, str) or not identity.strip() for identity in removals):
        raise HacdonaldsError("INVALID_CHANGES", "删除成员请提供有效成员 ID。")
    existing = {member["id"]: member for member in request["crew"]}
    touched = set()
    for update in updates:
        if (not isinstance(update, dict) or set(update) - (MEMBER_FIELDS | {"id"})
                or not isinstance(update.get("id"), str) or len(update) < 2):
            raise HacdonaldsError("INVALID_CHANGES", "member_updates 每项需要 id 和至少一个支持的成员字段。")
        identity = update["id"]
        if identity not in existing:
            raise HacdonaldsError("MEMBER_NOT_FOUND", "修改的成员 ID 不在当前团队中。")
        if identity in touched:
            raise HacdonaldsError("CONFLICTING_CHANGES", "同一成员不能在一次修改中重复出现。")
        touched.add(identity)
        existing[identity].update(deepcopy(update))
    for identity in removals:
        if identity not in existing:
            raise HacdonaldsError("MEMBER_NOT_FOUND", "删除的成员 ID 不在当前团队中。")
        if identity in touched:
            raise HacdonaldsError("CONFLICTING_CHANGES", "同一成员不能在一次修改中同时更新或重复删除。")
        touched.add(identity)
    added_ids = set()
    for member in additions:
        if not isinstance(member, dict) or not isinstance(member.get("id"), str):
            raise HacdonaldsError("INVALID_CHANGES", "新增成员需要完整的成员参数和唯一 id。")
        identity = member["id"]
        if identity in existing or identity in added_ids:
            raise HacdonaldsError("CONFLICTING_CHANGES", "新增成员 ID 不可与现有成员或其他新增成员重复。")
        added_ids.add(identity)
    request["crew"] = [member for member in request["crew"] if member["id"] not in removals] + deepcopy(additions)
    for field in ("budget_fen", "target_kcal"):
        if field in changes:
            request[field] = changes[field]
    normalized = parse_request(request)
    if normalized == parse_request(raw_request) and not allow_no_change:
        raise HacdonaldsError("NO_CHANGES", "本次修改没有改变需求；可使用 crew show 查看当前团队。")
    return normalized


def request_diff(before, after):
    previous = {member["id"]: member for member in before["crew"]} if before else {}
    current = {member["id"]: member for member in after["crew"]}
    fields = {}
    for field in ("store_code", "budget_fen", "target_kcal"):
        old = before.get(field) if before else None
        if old != after.get(field):
            fields[field] = {"before": old, "after": after.get(field)}
    updates = []
    for identity in current.keys() & previous.keys():
        edits = {field: {"before": previous[identity].get(field), "after": current[identity].get(field)}
                 for field in sorted(MEMBER_FIELDS) if previous[identity].get(field) != current[identity].get(field)}
        if edits:
            updates.append({"id": identity, "fields": edits})
    return {"fields": fields, "member_updates": sorted(updates, key=lambda item: item["id"]),
            "add_members": [deepcopy(member) for member in after["crew"] if member["id"] not in previous],
            "remove_member_ids": [member["id"] for member in before["crew"] if member["id"] not in current] if before else []}


def reservation_diff(before, after):
    return {identity: {"before": before.get(identity), "after": after.get(identity)}
            for identity in sorted(before.keys() | after.keys()) if before.get(identity) != after.get(identity)}


def food_diff(previous, result):
    if result.get("status") not in {"verified", "partial_verified"} or not result.get("plans"):
        return {"available": False, "reason": "NO_CURRENT_VERIFIED_PLAN"}
    if not previous:
        return {"available": False, "reason": "NO_VERIFIED_BASELINE"}
    def covered(value):
        if value.get("coverage") is not None:
            return set(value["coverage"]["covered_member_ids"])
        return {member["id"] for member in value.get("request", {}).get("crew", [])}
    if covered(previous["result"]) != covered(result):
        return {"available": False, "reason": "COVERAGE_CHANGED", "baseline_revision": previous["revision"]}
    old_plans = {plan["strategy"]: plan for plan in previous["result"]["plans"]}
    new_plans = {plan["strategy"]: plan for plan in result["plans"]}
    comparisons = []
    for strategy in sorted(old_plans.keys() | new_plans.keys()):
        old, new = old_plans.get(strategy), new_plans.get(strategy)
        if not old or not new:
            comparisons.append({"strategy": strategy, "change": "added" if new else "removed"})
            continue
        old_members = {a["member_id"]: a["products"] for a in old["assignments"]}
        new_members = {a["member_id"]: a["products"] for a in new["assignments"]}
        members = []
        for identity in sorted(old_members.keys() | new_members.keys()):
            old_counts = Counter(p["code"] for p in old_members.get(identity, []))
            new_counts = Counter(p["code"] for p in new_members.get(identity, []))
            if old_counts != new_counts:
                names = {p["code"]: p["name"] for p in old_members.get(identity, []) + new_members.get(identity, [])}
                members.append({"member_id": identity,
                    "removed": [{"code": code, "name": names[code], "quantity": count} for code, count in sorted((old_counts - new_counts).items())],
                    "added": [{"code": code, "name": names[code], "quantity": count} for code, count in sorted((new_counts - old_counts).items())]})
        comparisons.append({"strategy": strategy, "change": "updated" if members else "same_food",
                            "members": members,
                            "official_total_change_fen": new["official_quote"]["amount_fen"] - old["official_quote"]["amount_fen"]})
    return {"available": True, "baseline_revision": previous["revision"], "comparisons": comparisons}


def session_view(state):
    result = deepcopy(state)
    result["status"] = state["last_attempt"]["status"]
    result["last_verified_is_current"] = bool(state.get("last_verified") and state["last_verified"]["revision"] == state["revision"])
    if state.get("last_verified") and not result["last_verified_is_current"]:
        result["notice"] = "历史核价方案属于旧需求，不代表当前修改已成功，也不能作为当前报价。"
    return result


def check_revision(state, expected_revision):
    if type(expected_revision) is not int or expected_revision < 1:
        raise HacdonaldsError("INVALID_REVISION", "expected-revision 必须为大于 0 的整数。")
    if state["revision"] != expected_revision:
        raise HacdonaldsError("REVISION_CONFLICT", f"当前 revision 为 {state['revision']}；请先 crew show，再基于最新需求重新提交修改。")


async def _finish(store, state, planner, *, limit):
    previous = deepcopy(state.get("last_verified"))
    try:
        result = await plan_with_reservations(deepcopy(state["request"]), planner, limit=limit,
                                              reservations_fen=state.get("reservations_fen", {}))
        status = result["status"]
        if status in {"verified", "partial_verified"} and not result.get("plans"):
            raise HacdonaldsError("INVALID_PLAN_RESULT", "规划结果没有已核价方案，不能标记成功。")
        state["last_attempt"] = {"revision": state["revision"], "status": status, "result": result,
                                 "food_diff": food_diff(previous, result)}
        if "coverage" in result:
            state["coverage"] = deepcopy(result["coverage"])
        elif status == "verified":
            state["coverage"].update(complete=True, covered_member_ids=[m["id"] for m in state["request"]["crew"]], pending_member_ids=[])
        if status in {"verified", "partial_verified"}:
            state["last_verified"] = {"revision": state["revision"], "request": deepcopy(state["request"]),
                                      "reservations_fen": deepcopy(state.get("reservations_fen", {})),
                                      "verified_at": timestamp(), "result": deepcopy(result)}
    except (asyncio.CancelledError, KeyboardInterrupt):
        state["last_attempt"] = {"revision": state["revision"], "status": "cancelled", "error": {"code": "CANCELLED", "message": "本轮规划已取消，当前需求仍已保存。"}}
        state["updated_at"] = timestamp()
        state["history"][-1]["status"] = "cancelled"
        store.save(state)
        raise
    except Exception as exc:
        error = public_error(exc)
        state["last_attempt"] = {"revision": state["revision"], "status": "failed",
                                 "error": {"code": error.code, "message": str(error)},
                                 "recovery_options": recovery_options(code=error.code),
                                 "food_diff": {"available": False, "reason": "NO_CURRENT_VERIFIED_PLAN"}}
    state["updated_at"] = timestamp()
    state["history"][-1]["status"] = state["last_attempt"]["status"]
    store.save(state)
    return session_view(redact(state, store.token()))


async def start_crew(store, raw_request, planner, *, limit=24, dry_run=False, reservations_fen=None):
    request = parse_request(deepcopy(raw_request))
    prepared = prepare_request(request, reservations_fen)
    diff = request_diff(None, request)
    reserved_diff = reservation_diff({}, prepared["reservations_fen"])
    if dry_run:
        return {"status": "dry_run", "request": request, "request_diff": diff, "network_called": False, "state_saved": False,
                "reservation_diff": reserved_diff,
                "reservations_fen": prepared["reservations_fen"], "coverage": prepared["coverage"]}
    identity = store.new_id()
    now = timestamp()
    state = {"schema_version": 1, "session_id": identity, "revision": 1, "request": request,
             "reservations_fen": prepared["reservations_fen"], "coverage": prepared["coverage"],
             "created_at": now, "updated_at": now, "request_diff": diff, "reservation_diff": reserved_diff,
             "last_attempt": {"revision": 1, "status": "pending"}, "last_verified": None,
             "history": [{"revision": 1, "request_diff": diff, "reservation_diff": reserved_diff, "status": "pending"}]}
    with store.lock(identity):
        store.save(state)
        return await _finish(store, state, planner, limit=limit)


async def revise_crew(store, session_id, expected_revision, changes, planner, *, limit=24, dry_run=False, allow_no_change=False, reservations_fen=None):
    allow_no_change = allow_no_change or reservations_fen is not None
    # Read-only dry-run takes an atomic snapshot and never creates a lock file.
    if dry_run:
        state = store.load(session_id)
        check_revision(state, expected_revision)
        request = apply_changes(state["request"], changes, allow_no_change=allow_no_change)
        prepared = prepare_request(request, reservations_fen, inherited=state.get("reservations_fen", {}))
        return {"status": "dry_run", "session_id": session_id, "base_revision": expected_revision,
                "proposed_revision": expected_revision + 1, "request": request,
                "request_diff": request_diff(state["request"], request), "network_called": False, "state_saved": False,
                "reservation_diff": reservation_diff(state.get("reservations_fen", {}), prepared["reservations_fen"]),
                "reservations_fen": prepared["reservations_fen"], "coverage": prepared["coverage"]}
    # Validate before taking the write lock, then validate the revision again
    # while locked so a concurrent writer cannot invalidate the patch base.
    state = store.load(session_id)
    check_revision(state, expected_revision)
    request = apply_changes(state["request"], changes, allow_no_change=allow_no_change)
    prepared = prepare_request(request, reservations_fen, inherited=state.get("reservations_fen", {}))
    with store.lock(session_id):
        state = store.load(session_id)
        check_revision(state, expected_revision)
        diff = request_diff(state["request"], request)
        reserved_diff = reservation_diff(state.get("reservations_fen", {}), prepared["reservations_fen"])
        state.update(request=request, revision=expected_revision + 1, request_diff=diff, reservation_diff=reserved_diff, updated_at=timestamp(),
                     reservations_fen=prepared["reservations_fen"], coverage=prepared["coverage"],
                     last_attempt={"revision": expected_revision + 1, "status": "pending"})
        state["history"].append({"revision": state["revision"], "request_diff": diff, "reservation_diff": reserved_diff, "status": "pending"})
        store.save(state)
        return await _finish(store, state, planner, limit=limit)


def show_crew(store, session_id):
    return session_view(store.load(session_id))
