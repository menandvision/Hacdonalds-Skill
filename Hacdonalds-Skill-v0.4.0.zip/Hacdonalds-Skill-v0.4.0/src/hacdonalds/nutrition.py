"""Conservative official nutrition matching and per-person calorie arithmetic.

No model guesses or fuzzy product/size matches. Raw server text is only data.
Supported JSON/TOON records must identify a portion and a kcal/kJ unit.
"""

from collections import Counter
from copy import deepcopy
import csv
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import json
import re
import unicodedata

from .errors import HacdonaldsError, public_error

SOURCE = "list-nutrition-foods"
PER_ITEM = {"per_item", "per_serving", "serving", "item", "每份", "单份", "每个", "每杯", "单份餐品"}
KCAL_UNITS = {"kcal", "大卡", "千卡"}
KJ_UNITS = {"kj", "千焦", "千焦耳"}


def number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float, str, Decimal)):
        return None
    try:
        value = Decimal(str(value).strip())
        return value if value.is_finite() and 0 <= value <= 1000000 else None
    except InvalidOperation:
        return None


def rounded(value):
    return float(Decimal(str(value)).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP))


def product_kcal(product):
    nutrition = product.get("nutrition") if isinstance(product, dict) else None
    if not isinstance(nutrition, dict) or nutrition.get("status") != "matched" or nutrition.get("basis") != "per_item":
        return None
    value = number(nutrition.get("kcal_per_item"))
    return float(value) if value is not None else None


def canonical_name(name):
    if not isinstance(name, str):
        return ""
    name = unicodedata.normalize("NFKC", name).strip()
    # Observed menu UI suffix is not a serving size. All other qualifiers stay.
    name = re.sub(r"【可特调】$", "", name)
    name = re.sub(r"\s+", "", name).casefold()
    # Official nutrition labels can insert a separator before the same portion
    # (e.g. 鸡翅-2块 vs 鸡翅2块). Preserve the full quantity/size token.
    name = re.sub(r"[-·]?(?:\()?((?:\d+(?:\.\d+)?(?:块|个|片|杯|份)|[大中小]杯))(?:\))?$", r"\1", name)
    return name


def unknown(reason, retrieved_at=None):
    return {"status": "unknown", "kcal_per_item": None, "basis": "per_item",
            "source": SOURCE, "retrieved_at": retrieved_at, "reason": reason}


def _rows(data):
    """Return rows and format; bounded known wrappers, never arbitrary traversal."""
    for _ in range(6):
        if isinstance(data, list):
            if len(data) > 5000 or any(not isinstance(row, dict) for row in data):
                raise ValueError("unrecognized nutrition rows")
            return data, "json"
        if isinstance(data, dict):
            if "success" in data:
                if data["success"] is not True:
                    raise ValueError("nutrition business failure")
                data = data.get("data")
                continue
            keys = [key for key in ("foods", "items", "list", "nutritionFoods", "nutritionList", "data")
                    if isinstance(data.get(key), (list, dict, str))]
            if len(keys) != 1:
                raise ValueError("unrecognized nutrition container")
            data = data[keys[0]]
            continue
        if isinstance(data, str):
            text = data.strip()
            try:
                data = json.loads(text)
                continue
            except ValueError:
                pass
            # Some server text places one JSON business envelope after a
            # prose notice. Decode that envelope as data, never execute text.
            decoder, envelopes, position, attempts = json.JSONDecoder(), [], 0, 0
            while attempts < 32:
                position = text.find("{", position)
                if position < 0:
                    break
                attempts += 1
                try:
                    candidate, end = decoder.raw_decode(text, position)
                    position = end
                except ValueError:
                    position += 1
                    continue
                if isinstance(candidate, dict) and isinstance(candidate.get("data"), (str, list, dict)):
                    envelopes.append(candidate)
            if envelopes:
                if len(envelopes) != 1:
                    raise ValueError("ambiguous nutrition envelopes")
                data = envelopes[0]
                continue
            lines = text.splitlines()
            for index, line in enumerate(lines):
                header = re.fullmatch(r"\s*(?:\w+)?\[(\d+)\]\{([^}]+)\}:\s*", line)
                if not header:
                    continue
                count = int(header[1])
                columns = next(csv.reader([header[2]], strict=True))
                if count > 5000 or len(set(columns)) != len(columns):
                    raise ValueError("invalid TOON header")
                records = list(csv.reader(lines[index + 1:index + 1 + count], strict=True))
                trailing = [line.strip() for line in lines[index + 1 + count:] if line.strip() not in {"", "```"}]
                if trailing or len(records) != count or any(len(row) != len(columns) for row in records):
                    raise ValueError("truncated TOON nutrition")
                return [dict(zip(columns, (None if cell.strip() == "null" else cell.strip() for cell in row)))
                        for row in records], "toon"
            raise ValueError("unrecognized nutrition text")
        raise ValueError("unrecognized nutrition shape")
    raise ValueError("nutrition nesting exceeded")


def _energy(row):
    """energyKcal is the official product nutrition-calculator per-item field.

    The named official product record uses energyKcal/energyKj and
    nutritionDescription. A stated contrary basis is never overridden.
    """
    description = str(row.get("nutritionDescription") or "")
    basis = row.get("basis", row.get("servingBasis"))
    explicit_per_100g = any(word in description.casefold().replace(" ", "") for word in ("每100克", "每100g", "per100g", "每100ml", "每100毫升", "per100ml", "/100g", "/100ml"))
    per_item = basis in PER_ITEM if isinstance(basis, str) else False
    standard = "productName" in row and ("energyKcal" in row or "energyKj" in row)
    if basis is not None and not per_item:
        return None, "PORTION_UNVERIFIED"
    if explicit_per_100g:
        return None, "PORTION_UNVERIFIED"
    candidates = []
    for field in ("kcal_per_item", "kcal_per_serving", "energyKcal", "energy_kcal", "kcal"):
        if field in row and row[field] is not None and str(row[field]).strip():
            value = number(row[field])
            if value is None:
                return None, "ENERGY_INVALID"
            if field in {"kcal_per_item", "kcal_per_serving"} or per_item or standard:
                candidates.append(value)
            else:
                return None, "PORTION_UNVERIFIED"
    for field in ("energyKj", "energy_kj"):
        if field in row and row[field] is not None and str(row[field]).strip():
            value = number(row[field])
            if value is None:
                return None, "ENERGY_INVALID"
            if per_item or standard:
                candidates.append(value / Decimal("4.184"))
            else:
                return None, "PORTION_UNVERIFIED"
    if not candidates:
        energy = row.get("energy")
        unit = row.get("energyUnit", row.get("unit"))
        if isinstance(energy, dict):
            unit, energy = energy.get("unit"), energy.get("value")
        if isinstance(energy, str):
            match = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*(kcal|kJ|大卡|千卡|千焦|千焦耳)\s*", energy, re.I)
            if match:
                energy, unit = match.groups()
        value = number(energy)
        if not per_item:
            return None, "PORTION_UNVERIFIED"
        if value is None or not isinstance(unit, str):
            return None, "ENERGY_UNIT_UNKNOWN"
        if unit.casefold() in KCAL_UNITS:
            candidates.append(value)
        elif unit.casefold() in KJ_UNITS:
            candidates.append(value / Decimal("4.184"))
        else:
            return None, "ENERGY_UNIT_UNKNOWN"
    # kcal and kJ may both be rounded official values; reject real conflicts.
    if max(candidates) - min(candidates) > Decimal("2"):
        return None, "ENERGY_CONFLICT"
    return rounded(candidates[0]), None


def normalize_nutrition(response):
    rows, encoding = _rows(response.get("data"))
    entries = []
    for row in rows:
        name = row.get("productName", row.get("name", row.get("foodName")))
        if not isinstance(name, str) or not name.strip():
            continue
        kcal, reason = _energy(row)
        entries.append({"name": name, "product_code": row.get("productCode"),
                        "kcal_per_item": kcal, "reason": reason})
    return {"entries": entries, "retrieved_at": response.get("retrieved_at"), "encoding": encoding,
            "status": "available" if entries else "unavailable", "reason": None if entries else "NUTRITION_EMPTY"}


async def collect_nutrition(client):
    """One optional read, using the runtime input schema. No automatic retries."""
    try:
        arguments = {}
        if hasattr(client, "schema"):
            tool = await client.schema(SOURCE)
            schema = tool.get("input_schema", {})
            for key in schema.get("required", []):
                definition = schema.get("properties", {}).get(key, {})
                if "default" not in definition:
                    raise HacdonaldsError("NUTRITION_ARGUMENTS_REQUIRED", "营养工具需要尚未适配的参数。")
                arguments[key] = deepcopy(definition["default"])
        response = await client.call(SOURCE, arguments)
        return normalize_nutrition(response)
    except (ValueError, csv.Error):
        return {"status": "unavailable", "entries": [], "retrieved_at": None,
                "reason": "NUTRITION_SHAPE_UNKNOWN"}
    except Exception as error:
        return {"status": "unavailable", "entries": [], "retrieved_at": None,
                "reason": public_error(error).code}


def match_nutrition(product, catalogue):
    entries = catalogue.get("entries", [])
    name = canonical_name(product.get("name"))
    candidates = [entry for entry in entries if entry.get("product_code") == product.get("code")
                  and isinstance(entry.get("product_code"), str)]
    method = "code_and_name"
    if candidates:
        # Names still have to agree; generic food IDs are never ordering codes.
        candidates = [entry for entry in candidates if canonical_name(entry["name"]) == name]
    else:
        method = "exact_name"
        candidates = [entry for entry in entries if name and canonical_name(entry["name"]) == name]
    when = catalogue.get("retrieved_at")
    if not candidates:
        return unknown(catalogue.get("reason") or "NO_EXACT_NUTRITION_MATCH", when)
    if any(entry["kcal_per_item"] is None for entry in candidates):
        return unknown(next(entry["reason"] or "ENERGY_UNKNOWN" for entry in candidates if entry["kcal_per_item"] is None), when)
    amounts = {entry["kcal_per_item"] for entry in candidates}
    if len(amounts) != 1:
        return unknown("AMBIGUOUS_NUTRITION_MATCH", when)
    return {"status": "matched", "kcal_per_item": amounts.pop(), "source": SOURCE,
            "retrieved_at": when, "basis": "per_item", "match_method": method}


def _sum_products(products):
    total = Decimal("0")
    missing = Counter()
    times = set()
    for item in products:
        quantity = item.get("quantity", 1)
        if type(quantity) is not int or quantity <= 0:
            raise ValueError("invalid nutrition quantity")
        kcal = product_kcal(item)
        if kcal is None:
            missing[(item.get("code", ""), item.get("name", ""))] += quantity
        else:
            total += Decimal(str(kcal)) * quantity
        when = item.get("nutrition", {}).get("retrieved_at") if isinstance(item.get("nutrition"), dict) else None
        if isinstance(when, str) and when:
            times.add(when)
    complete = bool(products) and not missing
    return {"complete": complete, "total_kcal": rounded(total) if complete else None,
            "known_kcal": rounded(total),
            "missing_products": [{"code": code, "name": name, "quantity": count}
                                 for (code, name), count in sorted(missing.items())],
            "retrieved_at": sorted(times)}


def summarize_nutrition(assignments, request, *, partial=False):
    members = {member["id"]: member for member in request.get("crew", [])}
    all_products, summaries = [], []
    for assignment in assignments:
        products = assignment.get("products", [])
        all_products.extend(products)
        value = _sum_products(products)
        target = members.get(assignment["member_id"], {}).get("target_kcal")
        summaries.append(dict(value, member_id=assignment["member_id"], target_kcal=target,
                              difference_kcal=rounded(Decimal(str(value["total_kcal"])) - target)
                              if value["complete"] and target is not None else None))
    result = _sum_products(all_products)
    target = request.get("target_kcal")
    result.update(target_kcal=target, difference_kcal=rounded(Decimal(str(result["total_kcal"])) - target)
                  if result["complete"] and target is not None and not partial else None,
                  members=summaries, scope="covered_members" if partial else "full_team")
    return result
