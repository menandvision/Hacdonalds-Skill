"""A single static meal-result attachment, rendered from a factual summary."""

from datetime import datetime, timedelta, timezone
from html import escape
import math

from .explain import STATUS_NAMES, money


CSS = r"""
:root{--ink:#242522;--muted:#777872;--red:#bf292e;--gold:#ffc829;--paper:#fff;--base:#f3f3ef;--line:#e5e5df}
*{box-sizing:border-box}body{margin:0;background:var(--base);color:var(--ink);font-family:"Microsoft YaHei UI","PingFang SC",sans-serif;line-height:1.65;font-size:14px}.sheet{max-width:1080px;margin:0 auto;padding:44px 36px 28px}.masthead{display:flex;align-items:center;justify-content:space-between;gap:18px;padding-bottom:24px;border-bottom:1px solid #dcdcd4}.brand{display:flex;align-items:center;gap:12px}.brand-mark{display:block;width:34px;height:36px;position:relative;border-left:7px solid var(--gold);border-right:7px solid var(--gold);border-radius:40% 40% 0 0}.brand-mark:after{content:"";position:absolute;left:7px;top:0;height:36px;border-left:6px solid var(--gold)}.wordmark{font:800 27px Bahnschrift,"Arial Narrow",sans-serif;letter-spacing:-1px;line-height:1.2}.brand-sub{font-size:10px;letter-spacing:2px;margin-top:3px;color:var(--muted)}.status{font-size:11px;font-weight:700;border-radius:4px;padding:7px 12px;background:#e4ece4;color:#355342}.status.pending{background:#fff0c0;color:#73560a}.intro{padding:30px 0 22px}.title-row{display:flex;justify-content:space-between;align-items:baseline;gap:20px}.intro h1{font-size:30px;letter-spacing:-1px;margin:0 0 16px;font-weight:800}.strategy{font-size:12px;color:var(--red);font-weight:700}.metadata{display:flex;gap:8px 24px;flex-wrap:wrap;color:var(--muted);font-size:12px}.metadata b{color:var(--ink);font-weight:600;margin-left:5px}.quote-time{font-size:11px;color:var(--muted);margin-top:10px;overflow-wrap:anywhere}.coverage{padding:17px 20px;margin:0 0 22px;background:#fff2c6;border-left:3px solid var(--gold);font-size:12px}.coverage strong{display:block;font-size:13px;margin-bottom:5px}.coverage p{margin:3px 0}.members{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.member{border:1px solid var(--line);background:var(--paper);border-radius:10px;padding:23px 24px;break-inside:avoid}.member-head{display:flex;align-items:center;justify-content:space-between;gap:15px;padding-bottom:16px;border-bottom:1px solid #ededE7;margin-bottom:10px}.member-title{display:flex;align-items:center;gap:10px;min-width:0}.member-no{font:600 10px Bahnschrift,sans-serif;color:var(--muted);border:1px solid var(--line);height:25px;width:25px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0}.member h2{font-size:17px;line-height:1.35;margin:0;font-weight:700;overflow-wrap:anywhere}.member-calories{font:700 19px Bahnschrift,sans-serif;white-space:nowrap;color:#35382e}.member-calories small{font-size:10px;font-weight:400;color:var(--muted);margin-left:4px}.member-calories.unknown{font:600 11px "Microsoft YaHei UI",sans-serif;color:#997236}.food-list{margin:0;padding:0;list-style:none}.food-list li{display:flex;justify-content:space-between;gap:18px;align-items:baseline;padding:9px 0;font-size:13px;line-height:1.6}.food-list span{overflow-wrap:anywhere}.food-list b{font:700 15px Bahnschrift,sans-serif;flex-shrink:0;color:#575950}.nutrition-note{font-size:11px;color:#96712c;margin-top:11px;background:#faf5e8;border-radius:4px;padding:10px 12px;overflow-wrap:anywhere}.goal{color:var(--muted);font-size:11px;margin:12px 0 0;padding-top:12px;border-top:1px dashed var(--line)}.preferences{color:var(--muted);font-size:10px;margin-top:10px;overflow-wrap:anywhere}.preferences .unmatched{color:#a65b42}.summary{background:var(--ink);color:#fff;border-radius:10px;margin-top:25px;padding:25px 28px;display:grid;grid-template-columns:1fr 1.15fr 1fr;gap:25px}.metric+.metric{border-left:1px solid #494a43;padding-left:28px}.metric-label{font-size:11px;color:#c0c1b8}.metric-value{font:650 30px Bahnschrift,sans-serif;letter-spacing:-.6px;line-height:1.3;margin-top:9px}.metric-value small{font-size:12px;margin-left:5px;color:#c3c4bb;letter-spacing:0}.metric:first-child .metric-value{color:var(--gold)}.metric-note{font-size:10px;color:#c3c4bb;margin-top:7px;overflow-wrap:anywhere}.metric-goal{font-size:10px;color:#dadbd1;margin-top:6px;overflow-wrap:anywhere}.missing-list{font-size:11px;color:#8a6b30;padding:13px 4px 0;line-height:1.8;overflow-wrap:anywhere}.empty{padding:42px 28px;border:1px dashed #d6d6cb;border-radius:10px;text-align:center;background:#fff}.empty h2{font-size:20px;margin:0 0 8px}.empty p{font-size:12px;color:var(--muted);margin:0}.error,.recovery{font-size:12px;border:1px solid var(--line);border-radius:7px;background:#fff;padding:17px 20px;margin-top:14px;overflow-wrap:anywhere}.error strong,.recovery strong{display:block;font-size:13px;margin-bottom:5px}.recovery p,.error p{margin:5px 0;color:var(--muted)}.footer{margin-top:24px;padding-top:18px;border-top:1px solid #dcdcd4;color:#85867f;font-size:10px;line-height:1.85}.footer p{margin:2px 0;overflow-wrap:anywhere}@media(max-width:700px){.sheet{padding:25px 18px}.masthead{padding-bottom:20px;align-items:flex-start;gap:12px}.wordmark{font-size:23px}.brand-mark{transform:scale(.85);transform-origin:left center;margin-right:-5px}.brand-sub{font-size:8px;letter-spacing:1px}.status{font-size:9px;padding:6px 9px;max-width:130px}.intro{padding:26px 0 20px}.intro h1{font-size:25px}.title-row{align-items:center}.strategy{font-size:10px}.metadata{gap:7px 16px;font-size:11px}.members{grid-template-columns:1fr;gap:14px}.member{padding:20px}.summary{padding:22px 20px;gap:18px;grid-template-columns:1fr}.metric+.metric{border-left:none;border-top:1px solid #494a43;padding:16px 0 0}.metric-value{font-size:28px;margin-top:6px}.metric-label{font-size:11px}}@media print{body{background:white}.sheet{max-width:none;padding:0}.masthead{padding-bottom:18px}.intro{padding:20px 0}.intro h1{font-size:25px}.members{grid-template-columns:repeat(2,minmax(0,1fr));gap:13px}.member{padding:17px 19px}.summary{break-inside:avoid;background:#242522!important;color:white!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}.brand-mark,.status,.coverage{print-color-adjust:exact;-webkit-print-color-adjust:exact}.footer{margin-top:18px}@page{margin:14mm}}
"""


def _e(value):
    return escape(str(value if value is not None else "未提供"), quote=True)


def _number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        return "未提供"
    return f"{value:.1f}".rstrip("0").rstrip(".")


def _money_number(value):
    return f"{value / 100:.2f}" if type(value) is int else "—"


def _time(value):
    if not value:
        return "未提供"
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            return str(value)
        return parsed.astimezone(timezone(timedelta(hours=8))).strftime("%Y-%m-%d %H:%M:%S 北京时间")
    except (ValueError, TypeError):
        return str(value)


def _join(values):
    return "、".join(str(value) for value in values) or "无"


def _foods(products):
    return "、".join(f"{p.get('name', '未提供')} × {p.get('quantity', 1)}" for p in products) or "无"


def _goal(nutrition, *, partial=False):
    target = nutrition.get("target_kcal")
    if target is None:
        return ""
    text = f"本次目标 {_number(target)} kcal（尽量接近）"
    difference = nutrition.get("difference_kcal")
    if partial:
        text += "；仅覆盖部分成员，暂不比较全队目标"
    elif not nutrition.get("complete") or difference is None:
        text += "；热量待核实，暂不比较目标"
    elif difference == 0:
        text += "；与目标一致"
    else:
        text += f"；{'高于' if difference > 0 else '低于'}目标 {_number(abs(difference))} kcal"
    return text


def _member(assignment, index):
    nutrition = assignment.get("nutrition") or {}
    complete = nutrition.get("complete") and nutrition.get("total_kcal") is not None
    calorie = (f'<span class="member-calories">{_e(_number(nutrition["total_kcal"]))}<small>kcal</small></span>' if complete
               else '<span class="member-calories unknown">热量待核实</span>')
    foods = ''.join(f'<li><span>{_e(item.get("name"))}</span><b>× {_e(item.get("quantity", 1))}</b></li>'
                    for item in assignment.get("products", []))
    missing = '' if complete else ('<div class="nutrition-note">已知小计 ' + _e(_number(nutrition.get("known_kcal", 0)))
                                  + ' kcal；待核实：' + _e(_foods(nutrition.get("missing_products", []))) + '</div>')
    goal = _goal(nutrition)
    preferences = assignment.get("preferences") or {}
    preference = ''
    if preferences.get("matched") or preferences.get("unmatched"):
        preference = ('<div class="preferences">名称偏好已满足：' + _e(_join(preferences.get("matched", [])))
                      + '<br><span class="unmatched">未满足：' + _e(_join(preferences.get("unmatched", []))) + '</span></div>')
    return (f'<article class="member"><div class="member-head"><div class="member-title"><span class="member-no">{index:02d}</span>'
            f'<h2>{_e(assignment.get("member_id"))}</h2></div>{calorie}</div><ul class="food-list">{foods}</ul>{missing}'
            + (f'<p class="goal">{_e(goal)}</p>' if goal else '') + preference + '</article>')


def _summary(plan, *, partial=False):
    nutrition = plan.get("nutrition") or {}
    complete = nutrition.get("complete") and nutrition.get("total_kcal") is not None
    total_label = "已覆盖成员官方小计" if partial else "官方整篮总价"
    energy_label = "已覆盖成员热量小计" if partial else "全队总热量"
    balance_label = "预留后可用余额" if partial else "预算余额"
    energy = _number(nutrition.get("total_kcal")) if complete else "待核实"
    note = '' if complete else f'已知小计 {_number(nutrition.get("known_kcal", 0))} kcal'
    target = _goal(nutrition, partial=partial)
    result = ('<section class="summary" aria-label="本次餐单汇总">'
              f'<div class="metric"><div class="metric-label">{_e(total_label)}</div><div class="metric-value">¥ {_e(_money_number(plan.get("official_total_fen")))}</div></div>'
              f'<div class="metric"><div class="metric-label">{_e(energy_label)}</div><div class="metric-value">{_e(energy)}' + ('<small>kcal</small>' if complete else '')
              + '</div>' + (f'<div class="metric-note">{_e(note)}</div>' if note else '')
              + (f'<div class="metric-goal">{_e(target)}</div>' if target else '') + '</div>'
              f'<div class="metric"><div class="metric-label">{_e(balance_label)}</div><div class="metric-value">¥ {_e(_money_number(plan.get("remaining_budget_fen")))}</div></div></section>')
    if not complete:
        result += '<div class="missing-list">营养数据待核实：' + _e(_foods(nutrition.get("missing_products", []))) + '。完整热量尚不能确定，缺失项未按0计算。</div>'
    return result


def render_report(summary, *, generated_at=None):
    """Render one current meal; no history, client logic, or network requests."""
    generated_at = generated_at or datetime.now(timezone(timedelta(hours=8))).isoformat(timespec="seconds")
    status = summary.get("status", "unknown")
    current = summary.get("current", True) is True
    coverage = summary.get("coverage") or {}
    partial = status == "partial_verified" or bool(coverage.get("pending_dietary_member_ids"))
    plans = summary.get("plans", []) if current and status in {"verified", "partial_verified"} else []
    recommendation = summary.get("recommendation") or {}
    selected = next((plan for plan in plans if plan.get("strategy") == recommendation.get("strategy")), plans[0] if plans else None)
    if selected and (selected.get("nutrition") or {}).get("scope") == "covered_members":
        partial = True
    valid = selected is not None
    label = "部分成员已核价" if valid and partial else "官方整篮核价" if valid else "本次配餐未完成"
    status_class = '' if valid and not partial else ' pending'
    count = len(selected.get("assignments", [])) if valid else 0
    count_text = f"已覆盖 {count} 人" if partial else f"{count} 人" if valid else "尚未配餐"
    title = "本次配餐结果" if valid else "本次配餐状态"
    meta = [("人数", count_text), ("总预算", money(summary.get("budget_fen"))), ("门店编码", summary.get("store_code"))]
    if valid:
        meta.insert(2, ("官方小计" if partial else "官方总价", money(selected.get("official_total_fen"))))
    header = ('<header class="masthead"><div class="brand"><span class="brand-mark" aria-hidden="true"></span>'
              '<div><div class="wordmark">Hacdonald’s</div><div class="brand-sub">本次餐单 · 官方核价</div></div></div>'
              f'<span class="status{status_class}">{_e(label)}</span></header><section class="intro"><div class="title-row">'
              f'<h1>{title}</h1>' + (f'<span class="strategy">{_e(selected.get("strategy_name"))}</span>' if valid else '')
              + '</div><div class="metadata">' + ''.join(f'<span>{_e(key)}<b>{_e(value)}</b></span>' for key, value in meta)
              + '</div>' + (f'<div class="quote-time">原核价时间：{_e(_time(selected.get("quoted_at")))}</div>' if valid else '') + '</section>')
    content = ''
    if partial:
        coverage_title = "仅部分成员完成配餐，全队需求尚未完成" if valid else "禁忌需求待核实，全队配餐尚未完成"
        content += (f'<section class="coverage"><strong>{coverage_title}</strong>'
                    f'<p>已覆盖：{_e(_join(coverage.get("covered_member_ids", [])))}；待处理：{_e(_join(coverage.get("pending_member_ids", [])))}</p>'
                    f'<p>禁忌成员已确认预留 {_e(money(coverage.get("reserved_budget_fen")))}（不是消费）；其余成员可用 {_e(money(coverage.get("available_budget_fen")))}。</p></section>')
    if valid:
        content += ('<section class="members" aria-label="逐人餐品">'
                    + ''.join(_member(member, index + 1) for index, member in enumerate(selected.get("assignments", [])))
                    + '</section>' + _summary(selected, partial=partial))
    else:
        state = STATUS_NAMES.get(status, "尚未取得可展示的核价结果") if current else "保存记录与当前需求不一致，不能作为本次配餐结果"
        content += f'<section class="empty"><h2>当前没有已核价餐单</h2><p>{_e(state)}</p></section>'
        if summary.get("error"):
            error = summary["error"]
            content += f'<section class="error"><strong>本轮执行未完成</strong><p>{_e(error.get("code"))} · {_e(error.get("message"))}</p></section>'
    for option in summary.get("recovery_options", []):
        content += f'<section class="recovery"><strong>{_e(option.get("message"))}</strong><p>下一步：{_e(option.get("next_step"))}</p></section>'
    times = (selected.get("nutrition") or {}).get("retrieved_at", []) if valid else []
    footer = ('<footer class="footer"><p>热量按已匹配的官方单份营养数据和餐品数量计算，供参考；缺失数据不按0计。</p>'
              + (f'<p>营养数据获取时间：{_e(_join([_time(value) for value in times]))}</p>' if valid else '')
              + f'<p>报告生成时间：{_e(_time(generated_at))}。原核价及营养数据时间不因生成附件而更新。</p>'
              '<p>Hacdonald’s 是独立团队配餐项目，非麦当劳官方产品。</p></footer>')
    return ('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; script-src \'none\'; base-uri \'none\'; form-action \'none\'; connect-src \'none\'">'
            '<meta name="referrer" content="no-referrer"><title>Hacdonald’s · 本次餐单</title>'
            f'<style>{CSS}</style></head><body><main class="sheet">{header}{content}{footer}</main></body></html>')
