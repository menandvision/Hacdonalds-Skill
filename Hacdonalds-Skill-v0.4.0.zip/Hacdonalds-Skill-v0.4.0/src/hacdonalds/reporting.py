"""Local HTML exports are independent artifacts, never another business call."""

from datetime import datetime, timedelta, timezone
import os
from pathlib import Path
import tempfile
from uuid import uuid4

from .privacy import redact

REPORT_KINDS = {"plan", "crew-start", "crew-revise"}


def write_report(root, summary, *, kind="plan", token=""):
    """Write a unique report atomically; return safe metadata on any failure."""
    temporary, reserved = None, None
    try:
        from .html_report import render_report
        if kind not in REPORT_KINDS:
            raise ValueError("invalid report kind")
        root = Path(root).resolve()
        directory = root / ".local" / "reports"
        if not directory.resolve().is_relative_to(root):
            raise ValueError("report directory outside project")
        generated = datetime.now(timezone(timedelta(hours=8)))
        generated_at = generated.isoformat(timespec="seconds")
        content = render_report(redact(summary, token), generated_at=generated_at)
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd, temporary = tempfile.mkstemp(prefix=".report-", suffix=".tmp", dir=directory)
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        destination = directory / f"{generated:%Y%m%d-%H%M%S}-{kind}-{uuid4().hex[:12]}.html"
        # Reserve exclusively, so even an unlikely name collision cannot erase
        # an older export. Only our new reservation is replaced atomically.
        reserve_fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        os.close(reserve_fd)
        reserved = destination
        os.replace(temporary, destination)
        temporary, reserved = None, None
        return {"status": "written", "path": str(destination), "generated_at": generated_at}
    except Exception:
        return {"status": "failed", "code": "REPORT_WRITE_FAILED",
                "message": "HTML报告未能生成或保存；配餐结果仍保留。请检查项目.local/reports目录的写入权限和磁盘空间。"}
    finally:
        for path in (temporary, reserved):
            if path is not None:
                try:
                    Path(path).unlink(missing_ok=True)
                except OSError:
                    pass


def attach_report(result, root, *, kind="plan", token=""):
    summary = result.get("summary", {})
    if (result.get("status") not in {"verified", "partial_verified"}
            or result.get("view_only") or summary.get("current") is not True or not summary.get("plans")):
        return result
    return dict(result, report=write_report(root, result["summary"], kind=kind, token=token))
