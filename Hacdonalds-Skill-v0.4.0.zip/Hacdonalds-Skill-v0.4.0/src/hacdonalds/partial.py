"""Explicit budget reservations preserve dietary needs and partial coverage."""

from copy import deepcopy

from .errors import HacdonaldsError
from .planning import parse_request
from .nutrition import summarize_nutrition
from .recovery import with_recovery


def prepare_request(raw_request, reservations_fen=None, *, inherited=None):
    request = parse_request(deepcopy(raw_request))
    pending = [m["id"] for m in request["crew"] if m["avoid"]]
    eligible = [m["id"] for m in request["crew"] if not m["avoid"]]
    # Omitted means inherit only still-pending IDs. An explicit object fully
    # replaces the mapping; {} deliberately clears previous confirmation.
    reservations = ({identity: amount for identity, amount in (inherited or {}).items() if identity in pending}
                    if reservations_fen is None else deepcopy(reservations_fen))
    if (not isinstance(reservations, dict)
            or any(not isinstance(identity, str) or identity not in pending
                   or type(amount) is not int or amount <= 0 for identity, amount in reservations.items())):
        raise HacdonaldsError("INVALID_RESERVATIONS", "预留额只支持当前有 avoid 的成员 ID，金额必须为正整数分；未知或非禁忌成员不可预留。")
    reserved = sum(reservations.values())
    coverage = {"complete": False, "covered_member_ids": [], "pending_member_ids": [m["id"] for m in request["crew"]],
                "pending_dietary_member_ids": pending, "eligible_member_ids": eligible,
                "team_budget_fen": request["budget_fen"], "reserved_budget_fen": reserved,
                "available_budget_fen": request["budget_fen"] - reserved,
                "reservations_are_spending": False}
    base = {"request": request, "reservations_fen": reservations, "coverage": coverage, "effective_request": None}
    if not pending:
        return dict(base, effective_request=request, blocked_result=None)
    missing = [identity for identity in pending if identity not in reservations]
    if not eligible:
        blocked = dict(base, status="needs_dietary_verification", plans=[], recovery_options=[{
            "code": "VERIFY_DIETARY_REQUIREMENTS", "automatic": False,
            "message": "所有成员均有待核实的配料或过敏原禁忌，没有可安全先行规划的成员。",
            "next_step": "先取得官方配料确认，保留 avoid；本轮不联网、不生成或核价餐品。"}])
    elif missing:
        blocked = dict(base, status="needs_dietary_verification", plans=[], recovery_options=[{
            "code": "CONFIRM_DIETARY_RESERVATIONS", "automatic": False, "requires_confirmation": True,
            "member_ids": missing, "message": "尚未确认禁忌成员的预算预留额，不能把全队预算用于其余成员。",
            "next_step": "请明确询问这些成员各预留多少预算，确认后用 --reservations 文件提交；不要清空 avoid 或改成名称排除。"}])
    elif reserved >= request["budget_fen"]:
        blocked = dict(base, status="insufficient_unreserved_budget", plans=[], recovery_options=[{
            "code": "REVIEW_RESERVATION_BUDGET", "automatic": False,
            "message": "确认的预留总额已用尽或超过全队预算，其余成员没有正数可用预算。",
            "next_step": "请用户重新确认总预算或各成员预留额；本轮不联网，也不自动降低预留额。"}])
    else:
        # Keep the full-team target only in the original request; no implicit
        # calorie reservation or even allocation is made for pending members.
        effective = parse_request({"store_code": request["store_code"], "budget_fen": request["budget_fen"] - reserved,
                                   "crew": [deepcopy(m) for m in request["crew"] if not m["avoid"]]})
        return dict(base, effective_request=effective, blocked_result=None)
    return dict(base, blocked_result=blocked)


async def plan_with_reservations(raw_request, planner, *, reservations_fen=None, limit=24):
    prepared = prepare_request(raw_request, reservations_fen)
    if prepared["blocked_result"] is not None:
        return prepared["blocked_result"]
    result = await planner(deepcopy(prepared["effective_request"]), limit=limit)
    if not prepared["coverage"]["pending_dietary_member_ids"]:
        return with_recovery(result)
    result = deepcopy(result)
    coverage = deepcopy(prepared["coverage"])
    if result.get("status") == "verified" and not result.get("plans"):
        raise HacdonaldsError("INVALID_PARTIAL_RESULT", "部分规划没有已核价方案，不能标记成功。")
    successful = result.get("status") == "verified" and bool(result.get("plans"))
    if successful:
        for plan in result["plans"]:
            amount = plan.get("official_quote", {}).get("amount_fen")
            covered = [a["member_id"] for a in plan.get("assignments", [])]
            if (type(amount) is not int or not 0 <= amount <= coverage["available_budget_fen"]
                    or len(covered) != len(set(covered)) or set(covered) != set(coverage["eligible_member_ids"])):
                raise HacdonaldsError("INVALID_PARTIAL_RESULT", "部分方案的覆盖成员或官方小计不符合预留后预算，不能标记成功。")
            plan["remaining_budget_fen"] = coverage["available_budget_fen"] - amount
            plan["nutrition"] = summarize_nutrition(plan.get("assignments", []), prepared["request"], partial=True)
        coverage["covered_member_ids"] = list(coverage["eligible_member_ids"])
        coverage["pending_member_ids"] = list(coverage["pending_dietary_member_ids"])
    result.update(status="partial_verified" if successful else result.get("status", "no_verified_plan"),
                  request=prepared["request"], effective_request=prepared["effective_request"],
                  reservations_fen=prepared["reservations_fen"], coverage=coverage)
    return with_recovery(result)
