# 参赛材料状态

文档更新：2026-10-25（北京时间）。项目：Hacdonald's v0.4；公开仓库：[tedgamer-hub/Hacdonald-s](https://github.com/tedgamer-hub/Hacdonald-s)。**本项目尚未向官方发送报名 Issue；代码或文档准备完成不等于已报名。**

## 官方资料与提交

- [比赛仓库](https://github.com/M-China/mcd-developer-innovation-challenge)
- [活动规则](https://github.com/M-China/mcd-developer-innovation-challenge/blob/main/activityGuidelines.md)
- [官方参赛声明](https://github.com/M-China/mcd-developer-innovation-challenge/blob/main/CONTEST_DECLARATION.md)

现有规则记录要求在 2026 年 10 月 25 日 23:59（北京时间）前提交公开 GitHub 项目和报名 Issue。`CONTEST_DECLARATION.md` 保留官方原文，不在本轮修改。

README、集成说明、Skill、脱敏请求样例及源码已更新；当前v0.3已在历史演示门店完成真实营养、配餐和连续改单验收，记录见实施验证记录；v0.4静态附件已完成真实CLI自动生成验收；未向GitHub推送。以下正文是后续报名草稿，不是发送记录：

```text
〖参赛申请〗
项目名称：Hacdonald's
项目地址：https://github.com/tedgamer-hub/Hacdonald-s
项目简介：面向黑客松和开发团队的麦当劳配餐 Skill，将预算与逐人需求保存为可修改的团队会话，使用 Python 有界搜索生成餐单，通过麦当劳官方 MCP 核验整篮价格；保留禁忌与明确预留额，区分部分成员核价和全队完成；支持可选本次餐食热量目标与全队、逐人热量展示，配完自动生成本次餐单静态HTML附件。
```

## 验证与客户端声明

2026-10-24 13:57 的两轮真实团队核价属于历史版本，见 [脱敏摘要](examples/demo-session.md)。完整业务响应保留在原本机；v0.3本轮真实验收另见实施验证记录；该证据限于所测门店、时间和功能，不包含WorkBuddy客户端或部分规划的真实验收。

代码由 Codex 协助开发。本轮已提供 `.codebuddy/skills/hacdonalds/SKILL.md` 项目级适配及 [接入说明](WorkBuddy接入说明.md)，共用原 Skill 和 Python CLI。尚未进行 WorkBuddy 客户端实测，也没有真实 WorkBuddy 对话；未生成虚构 `workbuddy.md` 或开发上下文，不能据此宣称已符合专项奖励资格。后续客户端实际验证应另行记录证据。

项目不发布真实凭证、完整业务响应或个人截图；`.local`、虚拟环境和下载缓存不进入公开提交。现场截图、录屏或 PPT 需先脱敏，并标明历史核价时间与门店。
