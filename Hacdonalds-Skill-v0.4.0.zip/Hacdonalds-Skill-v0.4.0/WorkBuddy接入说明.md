# 在 WorkBuddy 中使用 Hacdonald's v0.4

项目已提供 `.codebuddy/skills/hacdonalds/SKILL.md` 薄入口，共用 [canonical Skill](skills/hacdonalds/SKILL.md) 和现有 Python CLI。**尚未在本机 WorkBuddy 客户端实际加载或对话验证；提供入口不等于接入实测通过。**

## 打开完整项目并加载 Skill

1. 使用已经安装的 WorkBuddy 打开完整源码目录，例如 `D:\AI-Tools\Hacdonalds\project`，保留 `start.cmd`、`scripts`、`src`、`skills`、`.codebuddy` 及 `uv.lock`。
2. 检查项目中的 [薄入口](.codebuddy/skills/hacdonalds/SKILL.md)。它只指向维护规范，不复制业务逻辑。具体客户端版本是否自动发现，仍需在客户端确认。
3. 若未自动加载，直接要求 WorkBuddy 读取实际项目下的 canonical Skill，例如：

```text
请先读取 D:\AI-Tools\Hacdonalds\project\skills\hacdonalds\SKILL.md，按其中的团队会话流程处理配餐。命令从该项目根目录执行，先做 dry-run，不要索取聊天中的 Token。
```

源码放在其他位置时，改成实际绝对路径。中文、空格目录也可用；终端执行绝对路径时使用引号，例如 `& "D:\比赛 项目\Hacdonald-s\start.cmd" doctor`。相对请求文件从项目根目录解析，先将终端工作目录切到项目根目录。

应使用完整源码压缩包或仓库克隆，不能只复制 `.codebuddy/skills` 文件夹：薄入口依赖原 Skill、请求协议及 Python 源码。若下载压缩包，检查隐藏目录 `.codebuddy` 也已包含。

## 共用已有入口

尚未初始化时，先按 [中文快速开始](中文快速开始.md) 运行 `setup.cmd`。环境和依赖放在 D 盘，要求已有 Python 3.11+；本步骤不安装 WorkBuddy 或 Python。

在项目根目录的自己的交互终端执行：

```powershell
.\start.cmd setup
.\start.cmd doctor --format text
.\start.cmd check --format text
```

`setup` 隐藏输入原始 Token，保存到项目 `.local/credentials.json`；Token 不发到聊天、不放命令参数。`doctor` 只看本地配置；`check` 联网检查工具发现，尚不能证明菜单或整篮核价成功。

这条接入使用同一 Python 客户端连接官方服务，无需在 WorkBuddy 另外配置一套麦当劳 MCP。也不更改全局 Skill、系统策略或客户端配置。

选定实际门店、更新请求文件后，让 WorkBuddy 使用相同命令：

```powershell
.\start.cmd crew start --request "examples/team-request.json" --dry-run --format text
.\start.cmd crew start --request "examples/team-request.json" --format text
.\start.cmd crew show --session "实际会话ID" --format text
.\start.cmd crew revise --session "实际会话ID" --expected-revision 1 --changes "examples/crew-changes.json" --dry-run --format text
```

示例门店位于沈阳，需换成实际查询并选定的编码；会话 ID 和 revision 使用刚返回的真实值。dry-run 不联网、不保存；正式修改也使用相同 `crew revise` 参数，去掉 `--dry-run`。失败保留当前需求（含已保存的修改），旧报价不代表本轮已完成。

遇到禁忌时保留 avoid，由你明确确认预留额，才能为其余成员规划。`partial_verified` 只代表部分覆盖；完整协议与预留映射规则统一以 canonical Skill 为准。

## 使用热量功能

继续使用同一 Skill 和 Python CLI，不需要额外营养插件或第二套配置。例如告诉 WorkBuddy：“三个人这一餐总共目标2100千卡，小王希望700千卡，预算80元；尽量接近热量目标，配完显示全队和每人的热量。”也可以不设热量目标，直接配餐后展示。

团队或成员的 `target_kcal` 仅对应本次餐食软目标，不是上限。连续修改可只改变某个成员目标，省略保持原值，显式 `null` 清除。使用 [热量请求示例](examples/calorie-request.json) 前替换实际门店，先 `crew start --dry-run` 再正式配餐；完整字段见 [请求协议](skills/hacdonalds/references/request-format.md)。

营养数据缺失时展示已知小计和待核实餐品，不把未知当0；仅部分成员配餐时，不声称全队热量达标。WorkBuddy客户端本轮仍未实测；共用Python CLI已完成真实营养查询、配餐和连续改单验收，见[实施验证记录](实施验证记录.md)。

## 查看本次配餐 HTML 附件

共用 Python CLI 仅在本次正式 `plan`、`crew start`、`crew revise` 取得完整或部分有效餐单后，才把结果附件写入项目 `.local/reports/`。要求状态为 `verified`／`partial_verified`、摘要 `current=true` 且 `plans` 非空。请让 WorkBuddy 将实际 `report.path` 作为可点击的本地链接返回，或给出完整绝对路径，用 Chrome 离线打开即可。

Hacdonald's 仍是 Skill。HTML 仅是本次推荐方案的静态清单，包含逐人餐品及数量、热量与偏好说明，官方整篮总价、总热量、预算余额、门店和原查询时间。附件无导航、脚本、按钮、方案切换、对比仪表盘或历史记录，可通过浏览器打印。需要调整时继续通过 Skill 的连续改单流程处理。

部分覆盖与未知热量在有效清单中明确标注。失败、待核实、未完成、无效需求、`--dry-run` 和只读 `crew show` 均不新增附件，当前状态及恢复建议仍由 Skill 对话或 CLI 返回，不从历史方案补生成。有效餐单的 HTML 写入失败仅返回 `report.status=failed`，保留原配餐结果，不因此重新联网。

附件可能含团队信息，仅保存在本机，`.local` 不进入源码 ZIP；公开前先脱敏。程序不默认打开浏览器。本说明描述共用 CLI 能力，不代表 WorkBuddy 客户端加载或附件链接显示已实测。

## 证据与官方说明

本项目按 [官方 Skills 文档中的项目级 `.codebuddy/skills/` 路径](https://www.workbuddy.ai/docs/zh/cli/skills) 提供薄入口。该页面属于 CodeBuddy Code/CLI 技能说明；WorkBuddy 的具体界面和发现机制仍需客户端实测。另见 [WorkBuddy 技能市场说明](https://www.workbuddy.ai/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Skills-Market)。

当前已提供项目级适配文件和本地格式检查，没有真实 WorkBuddy 对话、客户端成功截图或开发上下文记录。不要据此生成虚构 `workbuddy.md`、声称客户端验收成功，或宣称已符合专项奖励资格。
